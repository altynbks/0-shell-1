use crate::commands::{reason, split_flags, Io};
use std::collections::HashMap;
use std::fs::{self, Metadata};
use std::io::{self, Write};
use std::os::unix::fs::{FileTypeExt, MetadataExt};
use std::path::{Path, PathBuf};
use std::time::{SystemTime, UNIX_EPOCH};

struct Style {
    long: bool,
    classify: bool,
    color: bool,
    reverse: bool,
    recursive: bool,
}

struct Item {
    name: String,
    path: PathBuf,
    meta: Metadata,
}

pub fn ls(args: &[String], io: &mut Io) {
    let (flags, mut operands) = split_flags(args);
    let all = flags.contains('a');
    let style = Style { long: flags.contains('l'), classify: flags.contains('F'), color: io.color,
        reverse: flags.contains('r'), recursive: flags.contains('R') };
    let (long, classify) = (style.long, style.classify);
    if operands.is_empty() {
        operands.push(".".to_string());
    }

    let (mut files, mut dirs) = (Vec::new(), Vec::new());
    for op in &operands {
        let path = PathBuf::from(op);

        let meta = if long || classify {
            fs::symlink_metadata(&path)
        } else {
            fs::metadata(&path).or_else(|_| fs::symlink_metadata(&path))
        };
        match meta {
            Ok(m) if m.is_dir() => dirs.push(op.clone()),
            Ok(m) => files.push(Item { name: op.clone(), path, meta: m }),
            Err(e) => error!("ls: cannot access '{op}': {}", reason(&e)),
        }
    }

    print_items(&mut *io.out, &mut files, &style, false);
    dirs.sort();
    if style.reverse {
        dirs.reverse();
    }
    let header = operands.len() > 1 || style.recursive;
    let mut first = files.is_empty();
    for dir in &dirs {
        list_dir(io.out, dir, all, &style, header, &mut first);
    }
}

fn list_dir(out: &mut dyn Write, dir: &str, all: bool, st: &Style, header: bool, first: &mut bool) {
    if !*first {
        say!(out, "");
    }
    *first = false;
    if header {
        say!(out, "{dir}:");
    }
    let mut items = match read_dir_items(dir, all) {
        Ok(items) => items,
        Err(e) => return error!("ls: cannot open directory '{dir}': {}", reason(&e)),
    };
    print_items(out, &mut items, st, true);
    if st.recursive {
        for item in items.iter().filter(|i| i.meta.is_dir() && i.name != "." && i.name != "..") {
            list_dir(out, &item.path.to_string_lossy(), all, st, true, first);
        }
    }
}

fn read_dir_items(dir: &str, all: bool) -> io::Result<Vec<Item>> {
    let mut names = Vec::new();
    if all {
        names.push(".".to_string());
        names.push("..".to_string());
    }
    for entry in fs::read_dir(dir)? {
        let name = entry?.file_name().to_string_lossy().into_owned();
        if all || !name.starts_with('.') {
            names.push(name); 
        }
    }
    Ok(names
        .into_iter()
        .filter_map(|name| {
            let path = Path::new(dir).join(&name);
            let meta = fs::symlink_metadata(&path).ok()?;
            Some(Item { name, path, meta })
        })
        .collect())
}

fn suffix(m: &Metadata) -> &'static str {
    let t = m.file_type();
    if t.is_dir() {
        "/"
    } else if t.is_symlink() {
        "@"
    } else if t.is_fifo() {
        "|"
    } else if t.is_socket() {
        "="
    } else if t.is_file() && m.mode() & 0o111 != 0 {
        "*"
    } else {
        ""
    }
}

fn display(i: &Item, st: &Style) -> String {
    let t = i.meta.file_type();
    let code = if t.is_dir() {
        "1;34"
    } else if t.is_symlink() {
        "1;36"
    } else if t.is_char_device() || t.is_block_device() {
        "1;33"
    } else if t.is_fifo() || t.is_socket() {
        "33"
    } else if t.is_file() && i.meta.mode() & 0o111 != 0 {
        "1;32"
    } else {
        ""
    };
    let name = if st.color && !code.is_empty() { format!("\x1b[{code}m{}\x1b[0m", i.name) } else { i.name.clone() };
    format!("{name}{}", if st.classify { suffix(&i.meta) } else { "" })
}

fn print_items(out: &mut dyn Write, items: &mut Vec<Item>, st: &Style, in_dir: bool) {
    items.sort_by_key(|i| i.name.to_lowercase());
    if st.reverse {
        items.reverse();
    }

    if !st.long {
        for i in items.iter() {
            say!(out, "{}", display(i, st));
        }
        return;
    }

    if in_dir {
        let blocks: u64 = items.iter().map(|i| i.meta.blocks()).sum();
        say!(out, "total {}", (blocks + 1) / 2);
    }
    let users = id_names("/etc/passwd");
    let groups = id_names("/etc/group");

    let mut rows: Vec<([String; 6], String)> = Vec::new();
    for i in items.iter() {
        let m = &i.meta;
        let t = m.file_type();
        let size = if t.is_char_device() || t.is_block_device() {
            let r = m.rdev(); 
            format!("{}, {:>3}", ((r >> 8) & 0xfff) | ((r >> 32) & 0xffff_f000), (r & 0xff) | ((r >> 12) & 0xffff_ff00))
        } else {
            m.len().to_string()
        };
        let mut name = display(i, st);
        if t.is_symlink() {
            if let Ok(target) = fs::read_link(&i.path) {
                name.push_str(&format!(" -> {}", target.display()));
            }
        }
        let cols = [
            mode_string(m),
            m.nlink().to_string(),
            users.get(&m.uid()).cloned().unwrap_or_else(|| m.uid().to_string()),
            groups.get(&m.gid()).cloned().unwrap_or_else(|| m.gid().to_string()),
            size,
            date_string(m.mtime()),
        ];
        rows.push((cols, name));
    }

    let w = |c: usize| rows.iter().map(|(r, _)| r[c].chars().count()).max().unwrap_or(0);
    let (w1, w2, w3, w4) = (w(1), w(2), w(3), w(4));
    for (c, name) in &rows {
        say!(out, "{} {:>w1$} {:<w2$} {:<w3$} {:>w4$} {} {}", c[0], c[1], c[2], c[3], c[4], c[5], name);
    }
}

fn mode_string(m: &Metadata) -> String {
    let t = m.file_type();
    let kind = if t.is_dir() {
        'd'
    } else if t.is_symlink() {
        'l'
    } else if t.is_char_device() {
        'c'
    } else if t.is_block_device() {
        'b'
    } else if t.is_fifo() {
        'p'
    } else if t.is_socket() {
        's'
    } else {
        '-'
    };
    let mode = m.mode();
    let mut s: Vec<char> = vec![kind];
    for (i, ch) in "rwxrwxrwx".chars().enumerate() {
        s.push(if mode & (0o400 >> i) != 0 { ch } else { '-' });
    }

    for (bit, pos, ch) in [(0o4000, 3, 's'), (0o2000, 6, 's'), (0o1000, 9, 't')] {
        if mode & bit != 0 {
            s[pos] = if s[pos] == 'x' { ch } else { ch.to_ascii_uppercase() };
        }
    }
    s.into_iter().collect()
}

fn id_names(file: &str) -> HashMap<u32, String> {
    let mut map = HashMap::new();
    for line in fs::read_to_string(file).unwrap_or_default().lines() {
        let f: Vec<&str> = line.split(':').collect();
        if let (Some(name), Some(Ok(id))) = (f.first(), f.get(2).map(|s| s.parse::<u32>())) {
            map.entry(id).or_insert_with(|| name.to_string());
        }
    }
    map
}

#[repr(C)]
struct Tm {
    sec: i32,
    min: i32,
    hour: i32,
    mday: i32,
    mon: i32,
    year: i32,
    wday: i32,
    yday: i32,
    isdst: i32,
    gmtoff: i64,
    zone: *const u8,
}
extern "C" {
    fn localtime_r(t: *const i64, out: *mut Tm) -> *mut Tm;
}

fn date_string(mtime: i64) -> String {
    const MONTHS: [&str; 12] = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    let mut tm = std::mem::MaybeUninit::<Tm>::zeroed();
    if unsafe { localtime_r(&mtime, tm.as_mut_ptr()) }.is_null() {
        return "?".to_string();
    }
    let tm = unsafe { tm.assume_init() };
    let now = SystemTime::now().duration_since(UNIX_EPOCH).map(|d| d.as_secs() as i64).unwrap_or(0);
    let month = MONTHS[tm.mon.clamp(0, 11) as usize];
    if mtime > now - 15_778_476 && mtime <= now {
        format!("{month} {:>2} {:02}:{:02}", tm.mday, tm.hour, tm.min)
    } else {
        format!("{month} {:>2} {:>5}", tm.mday, tm.year + 1900)
    }
}
