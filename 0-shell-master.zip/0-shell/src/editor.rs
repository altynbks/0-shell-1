use crate::commands::RawStdin;
use crate::shell::BUILTINS;
use std::fs;
use std::io::{self, IsTerminal, Read, Write};

#[repr(C)]
#[derive(Clone, Copy)]
struct Termios {
    iflag: u32,
    oflag: u32,
    cflag: u32,
    lflag: u32,
    line: u8,
    cc: [u8; 32],
    ispeed: u32,
    ospeed: u32,
}
extern "C" {
    fn tcgetattr(fd: i32, t: *mut Termios) -> i32;
    fn tcsetattr(fd: i32, action: i32, t: *const Termios) -> i32;
}
const ISIG: u32 = 0o1;
const ICANON: u32 = 0o2;
const ECHO: u32 = 0o10;

struct RawMode(Termios);

impl RawMode {
    fn enable() -> Option<RawMode> {
        let mut t: Termios = unsafe { std::mem::zeroed() };
        if unsafe { tcgetattr(0, &mut t) } != 0 {
            return None;
        }
        let saved = t;
        t.lflag &= !(ICANON | ECHO | ISIG); 
        unsafe { tcsetattr(0, 0, &t) };
        Some(RawMode(saved))
    }
}
impl Drop for RawMode {
    fn drop(&mut self) {
        unsafe { tcsetattr(0, 0, &self.0) };
    }
}

fn read_byte() -> Option<u8> {
    let mut b = [0u8; 1];
    loop {
        match RawStdin.read(&mut b) {
            Ok(1) => return Some(b[0]),
            Err(e) if e.kind() == io::ErrorKind::Interrupted => continue,
            _ => return None,
        }
    }
}

fn read_char() -> Option<char> {
    let first = read_byte()?;
    let extra = match first {
        0xF0..=0xFF => 3,
        0xE0..=0xEF => 2,
        0xC0..=0xDF => 1,
        _ => 0,
    };
    let mut bytes = vec![first];
    for _ in 0..extra {
        bytes.push(read_byte()?);
    }
    String::from_utf8_lossy(&bytes).chars().next()
}

fn redraw(prompt: &str, buf: &[char], pos: usize) {
    let line: String = buf.iter().collect();
    let mut out = io::stdout();
    let _ = write!(out, "\r\x1b[K{prompt}{line}");
    if pos < buf.len() {
        let _ = write!(out, "\x1b[{}D", buf.len() - pos);
    }
    let _ = out.flush();
}

pub struct Editor {
    history: Vec<String>,

    pub interrupted: bool,
}

impl Editor {
    pub fn new() -> Self {
        Editor { history: Vec::new(), interrupted: false }
    }

    pub fn read_line(&mut self, prompt: &str) -> Option<String> {
        self.interrupted = false;
        let raw = if io::stdin().is_terminal() { RawMode::enable() } else { None };
        if raw.is_none() {
            return read_plain(prompt);
        }

        let mut buf: Vec<char> = Vec::new();
        let mut pos = 0; 
        let mut hist = self.history.len(); 
        let mut draft = String::new(); 
        redraw(prompt, &buf, pos);

        loop {
            match read_char()? {
                '\r' | '\n' => {
                    print!("\r\n");
                    let line: String = buf.iter().collect();
                    if !line.trim().is_empty() && self.history.last() != Some(&line) {
                        self.history.push(line.clone());
                    }
                    return Some(line);
                }
                '\x04' if buf.is_empty() => {
                    print!("\r\n");
                    return None; 
                }
                '\x03' => {

                    print!("^C\r\n");
                    self.interrupted = true;
                    return Some(String::new());
                }
                '\x7f' | '\x08' if pos > 0 => {
                    buf.remove(pos - 1);
                    pos -= 1;
                }
                '\x01' => pos = 0, 
                '\x05' => pos = buf.len(), 
                '\x15' => {
                    buf.drain(..pos);
                    pos = 0;
                }
                '\x0c' => print!("\x1b[2J\x1b[H"),
                '\t' => complete(&mut buf, &mut pos, prompt),
                '\x1b' => {
                    if read_byte() == Some(b'[') {
                        match read_byte() {
                            Some(b'A') if hist > 0 => {
                                if hist == self.history.len() {
                                    draft = buf.iter().collect();
                                }
                                hist -= 1;
                                buf = self.history[hist].chars().collect();
                                pos = buf.len();
                            }
                            Some(b'B') if hist < self.history.len() => {
                                hist += 1;
                                let text = if hist == self.history.len() { draft.clone() } else { self.history[hist].clone() };
                                buf = text.chars().collect();
                                pos = buf.len();
                            }
                            Some(b'C') if pos < buf.len() => pos += 1,
                            Some(b'D') if pos > 0 => pos -= 1,
                            Some(b'H') => pos = 0,
                            Some(b'F') => pos = buf.len(),
                            Some(b'3') => {
                                read_byte(); 
                                if pos < buf.len() {
                                    buf.remove(pos);
                                }
                            }
                            _ => {}
                        }
                    }
                }
                c if !c.is_control() => {
                    buf.insert(pos, c);
                    pos += 1;
                }
                _ => {}
            }
            redraw(prompt, &buf, pos);
        }
    }
}

fn read_plain(prompt: &str) -> Option<String> {
    print!("{prompt}");
    let _ = io::stdout().flush();
    let mut bytes = Vec::new();
    loop {
        match read_byte() {
            Some(b'\n') => break,
            Some(b) => bytes.push(b),
            None if bytes.is_empty() => return None,
            None => break,
        }
    }
    let line = String::from_utf8_lossy(&bytes).into_owned();
    Some(line.trim_end_matches('\r').to_string())
}

fn complete(buf: &mut Vec<char>, pos: &mut usize, prompt: &str) {
    let before: String = buf[..*pos].iter().collect();
    let start = before.rfind(' ').map_or(0, |i| i + 1);
    let word = &before[start..];
    let is_command = before[..start].trim().is_empty() && !word.contains('/');

    let mut candidates: Vec<String> = if is_command {
        BUILTINS.iter().filter(|c| c.starts_with(word)).map(|c| c.to_string()).collect()
    } else {
        path_candidates(word)
    };
    candidates.sort();
    let Some(first) = candidates.first() else { return };

    let mut common: Vec<char> = first.chars().collect();
    for c in &candidates {
        let n = common.iter().zip(c.chars()).take_while(|(a, b)| **a == *b).count();
        common.truncate(n);
    }
    let mut replacement: String = common.into_iter().collect();
    if candidates.len() == 1 && !replacement.ends_with('/') {
        replacement.push(' '); 
    }

    if replacement.chars().count() > word.chars().count() {
        let start_chars = before[..start].chars().count();
        let tail: Vec<char> = buf[*pos..].to_vec();
        buf.truncate(start_chars);
        buf.extend(replacement.chars());
        *pos = buf.len();
        buf.extend(tail);
    } else if candidates.len() > 1 {

        print!("\r\n{}\r\n", candidates.join("  "));
        redraw(prompt, buf, *pos);
    }
}

fn path_candidates(word: &str) -> Vec<String> {
    let (dir_part, prefix) = match word.rfind('/') {
        Some(i) => (&word[..=i], &word[i + 1..]),
        None => ("", word),
    };
    let dir = if dir_part.is_empty() { "." } else { dir_part };
    let Ok(entries) = fs::read_dir(dir) else { return Vec::new() };
    entries
        .flatten()
        .filter_map(|e| {
            let name = e.file_name().to_string_lossy().into_owned();
            if !name.starts_with(prefix) || (name.starts_with('.') && !prefix.starts_with('.')) {
                return None;
            }
            let slash = if e.path().is_dir() { "/" } else { "" };
            Some(format!("{dir_part}{name}{slash}"))
        })
        .collect()
}
