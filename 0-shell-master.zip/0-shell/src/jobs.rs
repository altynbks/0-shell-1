use std::io::{self, IsTerminal, Write};
use std::panic::{catch_unwind, AssertUnwindSafe};
use std::sync::atomic::{AtomicBool, AtomicI32, Ordering};
use std::sync::Mutex;
use std::thread::sleep;
use std::time::Duration;

extern "C" {
    fn fork() -> i32;
    fn getpid() -> i32;
    fn getpgrp() -> i32;
    fn setpgid(pid: i32, pgid: i32) -> i32;
    fn tcgetpgrp(fd: i32) -> i32;
    fn tcsetpgrp(fd: i32, pgrp: i32) -> i32;
    fn waitpid(pid: i32, status: *mut i32, options: i32) -> i32;
    fn kill(pid: i32, sig: i32) -> i32;
    fn signal(signum: i32, handler: usize) -> usize;
    fn _exit(code: i32) -> !;
    fn dup(fd: i32) -> i32;
    fn dup2(old: i32, new: i32) -> i32;
    fn close(fd: i32) -> i32;
    fn pipe(fds: *mut i32) -> i32;
}

const SIG_DFL: usize = 0;
const SIG_IGN: usize = 1;
const SIGHUP: i32 = 1;
const SIGINT: i32 = 2;
const SIGQUIT: i32 = 3;
const SIGPIPE: i32 = 13;
const SIGTERM: i32 = 15;
const SIGCONT: i32 = 18;
const SIGTSTP: i32 = 20;
const SIGTTIN: i32 = 21;
const SIGTTOU: i32 = 22;

const WNOHANG: i32 = 1;
const WUNTRACED: i32 = 2;
const WCONTINUED: i32 = 8;
const EINTR: i32 = 4;

const SIGNALS: &[(&str, i32)] = &[
    ("HUP", 1), ("INT", 2), ("QUIT", 3), ("ILL", 4), ("TRAP", 5), ("ABRT", 6), ("BUS", 7),
    ("FPE", 8), ("KILL", 9), ("USR1", 10), ("SEGV", 11), ("USR2", 12), ("PIPE", 13),
    ("ALRM", 14), ("TERM", 15), ("CHLD", 17), ("CONT", 18), ("STOP", 19), ("TSTP", 20),
    ("TTIN", 21), ("TTOU", 22),
];

static INTERACTIVE: AtomicBool = AtomicBool::new(false);
static SHELL_PGID: AtomicI32 = AtomicI32::new(0);
static IN_CHILD: AtomicBool = AtomicBool::new(false);
static INTERRUPTED: AtomicBool = AtomicBool::new(false);
static LAST_BG: AtomicI32 = AtomicI32::new(0);

#[derive(Clone, Copy, PartialEq, Debug)]
enum State {
    Running,
    Stopped(i32),
    Exited(i32),
    Signaled(i32),
}

impl State {
    fn finished(self) -> bool {
        matches!(self, State::Exited(_) | State::Signaled(_))
    }

    fn label(self) -> String {
        match self {
            State::Running => "Running".into(),
            State::Stopped(SIGTTIN) => "Stopped (tty input)".into(),
            State::Stopped(SIGTTOU) => "Stopped (tty output)".into(),
            State::Stopped(_) => "Stopped".into(),
            State::Exited(0) => "Done".into(),
            State::Exited(n) => format!("Exit {n}"),
            State::Signaled(s) => describe_signal(s),
        }
    }
}

struct Job {
    id: u32,
    pid: i32,
    cmd: String,
    state: State,

    notify: bool,
}

struct Table {
    jobs: Vec<Job>,

    recent: Vec<u32>,
    exit_warned: bool,
}

static TABLE: Mutex<Table> = Mutex::new(Table { jobs: Vec::new(), recent: Vec::new(), exit_warned: false });

fn table() -> std::sync::MutexGuard<'static, Table> {
    TABLE.lock().unwrap_or_else(|e| e.into_inner())
}

fn errno() -> i32 {
    io::Error::last_os_error().raw_os_error().unwrap_or(0)
}

fn describe_signal(sig: i32) -> String {
    match sig {
        1 => "Hangup",
        2 => "Interrupt",
        3 => "Quit",
        4 => "Illegal instruction",
        6 => "Aborted",
        7 => "Bus error",
        8 => "Floating point exception",
        9 => "Killed",
        10 => "User defined signal 1",
        11 => "Segmentation fault",
        12 => "User defined signal 2",
        13 => "Broken pipe",
        14 => "Alarm clock",
        15 => "Terminated",
        _ => return format!("Signal {sig}"),
    }
    .to_string()
}

fn w_stopped(st: i32) -> Option<i32> {
    (st & 0xff == 0x7f).then_some((st >> 8) & 0xff)
}
fn w_exited(st: i32) -> Option<i32> {
    (st & 0x7f == 0).then_some((st >> 8) & 0xff)
}
fn w_signaled(st: i32) -> Option<i32> {
    let s = st & 0x7f;
    (s != 0 && s != 0x7f).then_some(s)
}
fn w_continued(st: i32) -> bool {
    st == 0xffff
}

fn state_from_status(st: i32) -> Option<State> {
    if let Some(sig) = w_stopped(st) {
        Some(State::Stopped(sig))
    } else if let Some(code) = w_exited(st) {
        Some(State::Exited(code))
    } else if let Some(sig) = w_signaled(st) {
        Some(State::Signaled(sig))
    } else if w_continued(st) {
        Some(State::Running)
    } else {
        None
    }
}

pub fn status_code(st: i32) -> i32 {
    if let Some(c) = w_exited(st) {
        c
    } else if let Some(s) = w_signaled(st) {
        128 + s
    } else if let Some(s) = w_stopped(st) {
        128 + s
    } else {
        0
    }
}

pub fn in_child() -> bool {
    IN_CHILD.load(Ordering::Relaxed)
}

pub fn interrupted() -> bool {
    INTERRUPTED.load(Ordering::Relaxed)
}

pub fn clear_interrupt() {
    INTERRUPTED.store(false, Ordering::Relaxed);
}

pub fn last_bg_pid() -> i32 {
    LAST_BG.load(Ordering::Relaxed)
}

pub fn interactive() -> bool {
    INTERACTIVE.load(Ordering::Relaxed)
}

pub fn init() {
    if !io::stdin().is_terminal() || unsafe { tcgetpgrp(0) } < 0 {
        return;
    }
    unsafe {
        signal(SIGTSTP, SIG_IGN);
        signal(SIGTTIN, SIG_IGN);
        signal(SIGTTOU, SIG_IGN);
        signal(SIGQUIT, SIG_IGN);
        let pid = getpid();
        setpgid(pid, pid);
        let pgid = getpgrp();
        SHELL_PGID.store(pgid, Ordering::Relaxed);
        tcsetpgrp(0, pgid);
    }
    INTERACTIVE.store(true, Ordering::Relaxed);
}

fn give_terminal(pgid: i32) {
    if interactive() {
        unsafe { tcsetpgrp(0, pgid) };
    }
}

fn add_job(pid: i32, cmd: &str, state: State) -> u32 {
    let mut t = table();
    let id = t.jobs.iter().map(|j| j.id).max().unwrap_or(0) + 1;
    t.jobs.push(Job { id, pid, cmd: cmd.to_string(), state, notify: false });
    t.recent.insert(0, id);
    id
}

fn touch(t: &mut Table, id: u32) {
    t.recent.retain(|&r| r != id);
    t.recent.insert(0, id);
}

fn remove_finished(t: &mut Table) {
    let gone: Vec<u32> = t.jobs.iter().filter(|j| j.state.finished()).map(|j| j.id).collect();
    t.jobs.retain(|j| !j.state.finished());
    t.recent.retain(|r| !gone.contains(r));
}

fn marker(t: &Table, id: u32) -> char {
    match t.recent.iter().position(|&r| r == id) {
        Some(0) => '+',
        Some(1) => '-',
        _ => ' ',
    }
}

fn job_line(t: &Table, j: &Job, with_pid: bool) -> String {
    let head = if with_pid {
        format!("[{}]{} {}", j.id, marker(t, j.id), j.pid)
    } else {
        format!("[{}]{} ", j.id, marker(t, j.id))
    };
    let amp = if j.state == State::Running { " &" } else { "" };
    format!("{head} {:<24}{}{}", j.state.label(), j.cmd, amp)
}

fn reset_signals(all: bool) {
    let list: &[i32] = if all { &[SIGINT, SIGQUIT, SIGTSTP, SIGTTIN, SIGTTOU, SIGPIPE] } else { &[SIGINT, SIGQUIT, SIGPIPE] };
    for &sig in list {
        unsafe { signal(sig, SIG_DFL) };
    }
}

fn child_exit(work: impl FnOnce() -> i32) -> ! {
    let code = catch_unwind(AssertUnwindSafe(work)).unwrap_or(1);
    let _ = io::stdout().flush();
    unsafe { _exit(code) }
}

fn detach_stdin() {
    if let Ok(f) = std::fs::File::open("/dev/null") {
        use std::os::unix::io::AsRawFd;
        unsafe { dup2(f.as_raw_fd(), 0) };
    }
}

pub fn spawn(cmd: &str, background: bool, work: impl FnOnce() -> i32) -> i32 {
    let _ = io::stdout().flush();
    let pid = unsafe { fork() };
    if pid < 0 {
        error!("0-shell: fork: {}", io::Error::last_os_error());
        return 1;
    }
    if pid == 0 {
        unsafe {
            setpgid(0, 0);
            if interactive() && !background {
                tcsetpgrp(0, getpid());
            }
        }
        reset_signals(true);
        IN_CHILD.store(true, Ordering::Relaxed);
        if background && !interactive() {
            detach_stdin();
        }
        child_exit(work)
    }
    unsafe { setpgid(pid, pid) };
    if background {
        LAST_BG.store(pid, Ordering::Relaxed);
        let id = add_job(pid, cmd, State::Running);
        if io::stdin().is_terminal() {
            println!("[{id}] {pid}");
        }
        0
    } else {
        wait_foreground(pid, cmd, None)
    }
}

fn wait_pid_blocking(pid: i32) -> i32 {
    let mut st = 0;
    loop {
        let r = unsafe { waitpid(pid, &mut st, 0) };
        if r == -1 && errno() == EINTR {
            continue;
        }
        if r == -1 {
            return 0;
        }
        return st;
    }
}

pub fn isolated(text: &str, work: impl FnOnce() -> i32) -> i32 {
    if interactive() && !in_child() {
        return spawn(text, false, work);
    }
    let _ = io::stdout().flush();
    let pid = unsafe { fork() };
    if pid < 0 {
        error!("0-shell: fork: {}", io::Error::last_os_error());
        return 1;
    }
    if pid == 0 {
        reset_signals(false);
        IN_CHILD.store(true, Ordering::Relaxed);
        child_exit(work)
    }
    status_code(wait_pid_blocking(pid))
}

pub fn capture(work: impl FnOnce() -> i32) -> (Vec<u8>, i32) {
    use std::io::Read;
    use std::os::unix::io::FromRawFd;
    let mut fds = [-1i32; 2];
    if unsafe { pipe(fds.as_mut_ptr()) } != 0 {
        return (Vec::new(), 1);
    }
    let _ = io::stdout().flush();
    let pid = unsafe { fork() };
    if pid < 0 {
        unsafe {
            close(fds[0]);
            close(fds[1]);
        }
        return (Vec::new(), 1);
    }
    if pid == 0 {
        unsafe {
            close(fds[0]);
            dup2(fds[1], 1);
            close(fds[1]);
        }
        reset_signals(false);
        IN_CHILD.store(true, Ordering::Relaxed);
        child_exit(work)
    }
    unsafe { close(fds[1]) };
    let mut reader = unsafe { std::fs::File::from_raw_fd(fds[0]) };
    let mut buf = Vec::new();
    let _ = reader.read_to_end(&mut buf);
    drop(reader);
    (buf, status_code(wait_pid_blocking(pid)))
}

pub fn pipeline(stages: Vec<Box<dyn FnOnce() -> i32 + '_>>) -> i32 {
    let _ = io::stdout().flush();
    let count = stages.len();
    let mut pids = Vec::new();
    let mut prev = -1;
    for (i, stage) in stages.into_iter().enumerate() {
        let last = i + 1 == count;
        let mut fds = [-1i32; 2];
        if !last && unsafe { pipe(fds.as_mut_ptr()) } != 0 {
            error!("0-shell: pipe: {}", io::Error::last_os_error());
            break;
        }
        let pid = unsafe { fork() };
        if pid < 0 {
            error!("0-shell: fork: {}", io::Error::last_os_error());
            unsafe {
                if !last {
                    close(fds[0]);
                    close(fds[1]);
                }
            }
            break;
        }
        if pid == 0 {
            unsafe {
                if prev >= 0 {
                    dup2(prev, 0);
                    close(prev);
                }
                if !last {
                    dup2(fds[1], 1);
                    close(fds[0]);
                    close(fds[1]);
                }
            }
            reset_signals(false);
            IN_CHILD.store(true, Ordering::Relaxed);
            child_exit(stage)
        }
        unsafe {
            if prev >= 0 {
                close(prev);
            }
            if !last {
                close(fds[1]);
            }
        }
        prev = if last { -1 } else { fds[0] };
        pids.push(pid);
    }
    if prev >= 0 {
        unsafe { close(prev) };
    }
    let mut code = 1;
    for pid in pids {
        code = status_code(wait_pid_blocking(pid));
    }
    code
}

pub fn wait_all() -> i32 {
    let pids: Vec<i32> = table().jobs.iter().filter(|j| j.state == State::Running).map(|j| j.pid).collect();
    let mut code = 0;
    for pid in pids {
        let st = wait_pid_blocking(pid);
        code = status_code(st);
        let mut t = table();
        if let Some(j) = t.jobs.iter_mut().find(|j| j.pid == pid) {
            j.state = State::Exited(code);
            j.notify = false;
        }
    }
    remove_finished(&mut table());
    code
}

fn wait_foreground(pid: i32, cmd: &str, existing: Option<u32>) -> i32 {
    give_terminal(pid);
    let mut status = 0;
    loop {
        let r = unsafe { waitpid(pid, &mut status, WUNTRACED) };
        if r == -1 && errno() == EINTR {
            continue;
        }
        if r == -1 {
            status = 0;
        }
        break;
    }
    give_terminal(SHELL_PGID.load(Ordering::Relaxed));

    if let Some(sig) = w_stopped(status) {
        let line = {
            let mut t = table();
            let id = match existing {
                Some(id) => id,
                None => {
                    drop(t);
                    let id = add_job(pid, cmd, State::Running);
                    t = table();
                    id
                }
            };
            if let Some(j) = t.jobs.iter_mut().find(|j| j.id == id) {
                j.state = State::Stopped(sig);
                j.notify = false;
            }
            touch(&mut t, id);
            let j = t.jobs.iter().find(|j| j.id == id).unwrap();
            job_line(&t, j, false)
        };
        println!("\n{line}");
        INTERRUPTED.store(true, Ordering::Relaxed);
    } else {
        if let Some(id) = existing {
            let mut t = table();
            t.jobs.retain(|j| j.id != id);
            t.recent.retain(|&r| r != id);
        }
        match w_signaled(status) {
            Some(SIGINT) => {
                println!();
                INTERRUPTED.store(true, Ordering::Relaxed);
            }
            Some(SIGPIPE) | None => {}
            Some(sig) => println!("{}", describe_signal(sig)),
        }
    }
    status_code(status)
}

fn refresh() {
    let mut t = table();
    for j in t.jobs.iter_mut().filter(|j| !j.state.finished()) {
        loop {
            let mut st = 0;
            let r = unsafe { waitpid(j.pid, &mut st, WNOHANG | WUNTRACED | WCONTINUED) };
            if r == 0 {
                break;
            }
            if r < 0 {
                if errno() == EINTR {
                    continue;
                }
                j.state = State::Exited(0); 
                j.notify = true;
                break;
            }
            if let Some(new) = state_from_status(st) {
                j.notify = new != State::Running;
                j.state = new;
                if new.finished() {
                    break;
                }
            }
        }
    }
}

pub fn notify() {
    refresh();
    let mut t = table();
    let mut lines = Vec::new();
    for j in t.jobs.iter().filter(|j| j.notify) {
        lines.push((j.id, job_line(&t, j, false)));
    }
    lines.sort_by_key(|(id, _)| *id);
    for j in t.jobs.iter_mut() {
        j.notify = false;
    }
    for (_, line) in &lines {
        println!("{line}");
    }
    remove_finished(&mut t);
    let _ = io::stdout().flush();
}

pub fn confirm_exit() -> bool {
    refresh();
    let mut t = table();
    let stopped = t.jobs.iter().any(|j| matches!(j.state, State::Stopped(_)));
    if stopped && !t.exit_warned {
        t.exit_warned = true;
        println!("There are stopped jobs.");
        return false;
    }
    true
}

pub fn clear_exit_warning() {
    table().exit_warned = false;
}

pub fn shutdown() {
    for j in table().jobs.iter().filter(|j| !j.state.finished()) {
        unsafe {
            kill(-j.pid, SIGHUP);
            kill(-j.pid, SIGCONT);
        }
    }
}

fn resolve(cmd: &str, spec: Option<&String>) -> Result<u32, String> {
    let t = table();
    let Some(spec) = spec else {
        return t.recent.first().copied().ok_or_else(|| format!("{cmd}: no current job"));
    };
    let name = spec.strip_prefix('%').unwrap_or(spec);
    let found = match name {
        "" | "+" | "%" => t.recent.first().copied(),
        "-" => t.recent.get(1).copied(),
        _ if name.chars().all(|c| c.is_ascii_digit()) => {
            name.parse().ok().filter(|id| t.jobs.iter().any(|j| j.id == *id))
        }
        _ => {
            let needle = name.strip_prefix('?');
            t.recent.iter().copied().find(|id| {
                let j = t.jobs.iter().find(|j| j.id == *id).unwrap();
                match needle {
                    Some(n) => j.cmd.contains(n),
                    None => j.cmd.starts_with(name),
                }
            })
        }
    };
    found.ok_or_else(|| format!("{cmd}: {spec}: no such job"))
}

pub fn jobs(args: &[String], out: &mut dyn Write) {
    let (mut long, mut pids_only) = (false, false);
    for a in args {
        match a.as_str() {
            "-l" => long = true,
            "-p" => pids_only = true,
            _ => return error!("jobs: {a}: invalid option\njobs: usage: jobs [-lp]"),
        }
    }
    refresh();
    let mut t = table();
    let mut ids: Vec<u32> = t.jobs.iter().map(|j| j.id).collect();
    ids.sort();
    for id in ids {
        let j = t.jobs.iter().find(|j| j.id == id).unwrap();
        if pids_only {
            let _ = writeln!(out, "{}", j.pid);
        } else {
            let _ = writeln!(out, "{}", job_line(&t, j, long));
        }
    }
    for j in t.jobs.iter_mut() {
        j.notify = false;
    }
    remove_finished(&mut t);
}

pub fn fg(args: &[String]) {
    let id = match resolve("fg", args.first()) {
        Ok(id) => id,
        Err(e) => return error!("{e}"),
    };
    let (pid, cmd) = {
        let mut t = table();
        touch(&mut t, id);
        let j = t.jobs.iter_mut().find(|j| j.id == id).unwrap();
        j.state = State::Running;
        j.notify = false;
        (j.pid, j.cmd.clone())
    };
    println!("{cmd}");
    let _ = io::stdout().flush();
    give_terminal(pid);
    unsafe { kill(-pid, SIGCONT) };
    let code = wait_foreground(pid, &cmd, Some(id));
    crate::commands::set_status(code);
}

pub fn bg(args: &[String], out: &mut dyn Write) {
    let id = match resolve("bg", args.first()) {
        Ok(id) => id,
        Err(e) => return error!("{e}"),
    };
    let mut t = table();
    touch(&mut t, id);
    let j = t.jobs.iter_mut().find(|j| j.id == id).unwrap();
    if j.state == State::Running {
        return error!("bg: job {id} already in background");
    }
    j.state = State::Running;
    j.notify = false;
    unsafe { kill(-j.pid, SIGCONT) };
    let (m, cmd) = (marker(&t, id), t.jobs.iter().find(|j| j.id == id).unwrap().cmd.clone());
    let _ = writeln!(out, "[{id}]{m} {cmd} &");
}

fn parse_signal(s: &str) -> Option<i32> {
    if let Ok(n) = s.parse::<i32>() {
        return (0..=64).contains(&n).then_some(n);
    }
    let name = s.to_ascii_uppercase();
    let name = name.strip_prefix("SIG").unwrap_or(&name);
    SIGNALS.iter().find(|(n, _)| *n == name).map(|(_, v)| *v)
}

pub fn kill_cmd(args: &[String], out: &mut dyn Write) {
    let usage = "kill: usage: kill [-s sigspec | -n signum | -sigspec] pid | %jobspec ... or kill -l";
    let mut sig = SIGTERM;
    let mut i = 0;

    if args.first().map(String::as_str) == Some("-l") {
        let list: Vec<String> = SIGNALS.iter().map(|(n, v)| format!("{v}) SIG{n}")).collect();
        let _ = writeln!(out, "{}", list.join("  "));
        return;
    }
    match args.first().map(String::as_str) {
        Some("-s") | Some("-n") => {
            let Some(spec) = args.get(1) else { return error!("kill: {}: option requires an argument", args[0]) };
            match parse_signal(spec) {
                Some(s) => sig = s,
                None => return error!("kill: {spec}: invalid signal specification"),
            }
            i = 2;
        }
        Some(a) if a.len() > 1 && a.starts_with('-') && a != "--" => match parse_signal(&a[1..]) {
            Some(s) => {
                sig = s;
                i = 1;
            }
            None => return error!("kill: {}: invalid signal specification", &a[1..]),
        },
        _ => {}
    }
    if args.get(i).map(String::as_str) == Some("--") {
        i += 1;
    }
    if i >= args.len() {
        return error!("{usage}");
    }

    refresh();
    let mut touched = Vec::new();
    for target in &args[i..] {
        let (pid, group, stopped) = if target.starts_with('%') {
            match resolve("kill", Some(target)) {
                Ok(id) => {
                    let t = table();
                    let j = t.jobs.iter().find(|j| j.id == id).unwrap();
                    (j.pid, true, matches!(j.state, State::Stopped(_)))
                }
                Err(e) => {
                    error!("{e}");
                    continue;
                }
            }
        } else if let Ok(pid) = target.parse::<i32>() {
            let stopped = table().jobs.iter().any(|j| j.pid == pid && matches!(j.state, State::Stopped(_)));
            (pid, false, stopped)
        } else {
            error!("kill: {target}: arguments must be process or job IDs");
            continue;
        };

        let dest = if group { -pid } else { pid };
        if unsafe { kill(dest, sig) } != 0 {
            let e = io::Error::last_os_error();
            error!("kill: ({pid}) - {}", crate::commands::reason(&e));
            continue;
        }

        if stopped && (sig == SIGTERM || sig == SIGHUP) {
            unsafe { kill(dest, SIGCONT) };
        }
        if sig != 0 {
            touched.push(pid);
        }
    }
    settle(&touched);
}

fn settle(pids: &[i32]) {
    if pids.is_empty() {
        return;
    }
    let snapshot = |pids: &[i32]| -> Vec<Option<State>> {
        let t = table();
        pids.iter().map(|p| t.jobs.iter().find(|j| j.pid == *p).map(|j| j.state)).collect()
    };
    let before = snapshot(pids);
    for _ in 0..30 {
        sleep(Duration::from_millis(10));
        refresh();
        if snapshot(pids) != before {
            break;
        }
    }
}

pub struct FdGuard {
    saved: i32,
    fd: i32,
}

impl FdGuard {
    pub fn redirect(from: i32, fd: i32) -> FdGuard {
        let _ = io::stdout().flush();
        let _ = io::stderr().flush();
        let saved = unsafe { dup(fd) };
        unsafe { dup2(from, fd) };
        FdGuard { saved, fd }
    }
}

impl Drop for FdGuard {
    fn drop(&mut self) {
        let _ = io::stdout().flush();
        unsafe {
            if self.saved >= 0 {
                dup2(self.saved, self.fd);
                close(self.saved);
            } else {
                close(self.fd);
            }
        }
    }
}
