use std::fs::{self, File};
use std::io::{self, IsTerminal, Read, Write};
use std::os::unix::fs::{symlink, MetadataExt};
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicBool, AtomicI32, Ordering};

static ERROR_SEEN: AtomicBool = AtomicBool::new(false);
static STATUS_OVERRIDE: AtomicI32 = AtomicI32::new(-1);

pub fn set_status(code: i32) {
    STATUS_OVERRIDE.store(code, Ordering::Relaxed);
}

pub fn take_status() -> i32 {
    let explicit = STATUS_OVERRIDE.swap(-1, Ordering::Relaxed);
    let failed = ERROR_SEEN.swap(false, Ordering::Relaxed);
    if explicit >= 0 {
        explicit
    } else if failed {
        1
    } else {
        0
    }
}

pub struct RawStdin;

extern "C" {
    fn read(fd: i32, buf: *mut u8, count: usize) -> isize;
}

impl Read for RawStdin {
    fn read(&mut self, buf: &mut [u8]) -> io::Result<usize> {
        loop {
            let n = unsafe { read(0, buf.as_mut_ptr(), buf.len()) };
            if n >= 0 {
                return Ok(n as usize);
            }
            let err = io::Error::last_os_error();
            if err.kind() != io::ErrorKind::Interrupted {
                return Err(err);
            }
        }
    }
}

pub struct Io<'a> {
    pub input: &'a mut dyn Read,
    pub out: &'a mut dyn Write,
    pub color: bool,
}

pub fn print_error(msg: &str) {
    ERROR_SEEN.store(true, Ordering::Relaxed);
    if io::stderr().is_terminal() {
        eprintln!("\x1b[31m{msg}\x1b[0m");
    } else {
        eprintln!("{msg}");
    }
}

pub fn reason(e: &io::Error) -> String {
    let s = e.to_string();
    s.split(" (os error").next().unwrap_or(&s).to_string()
}

pub fn split_flags(args: &[String]) -> (String, Vec<String>) {
    let mut flags = String::new();
    let mut paths = Vec::new();
    for a in args {
        if a.len() > 1 && a.starts_with('-') {
            flags.push_str(&a[1..]);
        } else {
            paths.push(a.clone());
        }
    }
    (flags, paths)
}

pub fn echo(args: &[String], io: &mut Io) {
    let (mut newline, mut escapes, mut start) = (true, false, 0);
    while let Some(a) = args.get(start) {
        let flags = a.strip_prefix('-').filter(|f| !f.is_empty() && f.chars().all(|c| matches!(c, 'n' | 'e' | 'E')));
        let Some(flags) = flags else { break };
        for f in flags.chars() {
            match f {
                'n' => newline = false,
                'e' => escapes = true,
                _ => escapes = false,
            }
        }
        start += 1;
    }
    let mut text = args[start..].join(" ");
    if escapes {
        let (t, stop) = crate::builtins::unescape(&text);
        text = t;
        if stop {
            newline = false;
        }
    }
    let _ = write!(io.out, "{text}{}", if newline { "\n" } else { "" });
}

pub fn sleep(args: &[String]) {
    if args.is_empty() {
        return error!("sleep: missing operand");
    }
    let mut total = 0.0f64;
    for a in args {
        let (num, mult) = match a.chars().last() {
            Some('s') => (&a[..a.len() - 1], 1.0),
            Some('m') => (&a[..a.len() - 1], 60.0),
            Some('h') => (&a[..a.len() - 1], 3600.0),
            Some('d') => (&a[..a.len() - 1], 86400.0),
            _ => (a.as_str(), 1.0),
        };
        match num.parse::<f64>() {
            Ok(v) if v >= 0.0 && v.is_finite() => total += v * mult,
            _ => return error!("sleep: invalid time interval '{a}'"),
        }
    }
    std::thread::sleep(std::time::Duration::from_secs_f64(total));
}

pub fn pwd(io: &mut Io) {
    match std::env::current_dir() {
        Ok(dir) => say!(io.out, "{}", dir.display()),
        Err(e) => error!("pwd: {}", reason(&e)),
    }
}

pub fn cd(args: &[String], io: &mut Io) {

    let target = match args.first().map(String::as_str) {
        None => std::env::var("HOME").unwrap_or_else(|_| "/".to_string()),
        Some("-") => match std::env::var("OLDPWD") {
            Ok(old) => {
                say!(io.out, "{old}");
                old
            }
            Err(_) => return error!("cd: OLDPWD not set"),
        },
        Some(path) => path.to_string(),
    };
    let before = std::env::current_dir().ok();
    match std::env::set_current_dir(&target) {
        Ok(()) => {
            if let Some(b) = before {
                std::env::set_var("OLDPWD", b);
            }
            if let Ok(now) = std::env::current_dir() {
                std::env::set_var("PWD", now);
            }
        }
        Err(e) => error!("cd: {target}: {}", reason(&e)),
    }
}

pub fn cat(args: &[String], io: &mut Io) {
    if args.is_empty() {
        let _ = io::copy(&mut *io.input, &mut *io.out); 
    }
    for path in args {
        let result = File::open(path).and_then(|mut f| io::copy(&mut f, &mut *io.out));
        if let Err(e) = result {
            error!("cat: {path}: {}", reason(&e));
        }
    }
}

pub fn export(args: &[String], io: &mut Io) {
    if args.is_empty() {
        let mut vars: Vec<_> = std::env::vars().collect();
        vars.sort();
        for (k, v) in vars {
            say!(io.out, "export {k}=\"{v}\"");
        }
    }
    for arg in args.iter().filter(|a| !a.starts_with('-')) {
        let (name, value) = match arg.split_once('=') {
            Some((n, v)) => (n, Some(v)),
            None => (arg.as_str(), None),
        };
        if !crate::vars::is_name(name) {
            error!("export: '{arg}': not a valid identifier");
        } else if let Some(v) = value {
            crate::vars::set(name, v);
        }
    }
}

pub fn help(io: &mut Io) {
    say!(io.out, "0-shell built-in commands:");
    for line in [
        "echo [-n -e] [text]   print text",
        "cd [dir | -]          change directory (no argument: $HOME)",
        "pwd                   print current directory",
        "ls [-l -a -F -R -r]   list directory contents",
        "cat [file]            print files (or input)",
        "cp [-r] src... dest   copy files and directories",
        "mv src... dest        move or rename",
        "rm [-r -f] path...    remove files and directories",
        "mkdir [-p] dir...     create directories",
        "export NAME=value     set an environment variable",
        "sleep N               pause for N seconds",
        "jobs [-l -p]          list background and stopped jobs",
        "fg [%n]               bring a job to the foreground",
        "bg [%n]               resume a stopped job in the background",
        "kill [-SIG] pid|%n    send a signal (default TERM); kill -l lists signals",
        "wait                  wait for background jobs",
        "clear                 clear the screen",
        "exit [n]              leave the shell",
        "",
        "scripting builtins:",
        "read [-r -p text] var...   read a line into variables",
        "test / [ ] / [[ ]]         conditions (-f -d -e -z -n = != -eq -lt ...)",
        "printf fmt args...         formatted output",
        "source file / . file       run a script in the current shell",
        "sh file / bash file        run a script in a separate process",
        "shift [n]  unset  local  set --  return [n]  break  continue  eval  true  false  :",
    ] {
        say!(io.out, "  {line}");
    }
    say!(io.out, "Syntax: a ; b   a | b   a && b   a || b   cmd &   > >> < 2> 2>&1");
    say!(io.out, "        VAR=x  $VAR ${{VAR:-d}} $(cmd) $((1+2)) $? $1 $@ $#  ~  \"quotes\"");
    say!(io.out, "        if/elif/else/fi  while/until/do/done  for x in ..; do  for ((i=0;i<n;i++))  case..esac  name() {{ }}");
    say!(io.out, "Keys:   Up/Down history, Tab completion, Ctrl+C cancel line / interrupt job, Ctrl+Z stop job, Ctrl+D exit");
}

pub fn mkdir(args: &[String]) {
    let (flags, paths) = split_flags(args);
    if paths.is_empty() {
        error!("mkdir: missing operand");
    }
    for path in &paths {
        let result = if flags.contains('p') { fs::create_dir_all(path) } else { fs::create_dir(path) };
        if let Err(e) = result {
            error!("mkdir: cannot create directory '{path}': {}", reason(&e));
        }
    }
}

pub fn rm(args: &[String]) {
    let (flags, paths) = split_flags(args);
    if paths.is_empty() && !flags.contains('f') {
        error!("rm: missing operand");
    }
    for p in &paths {
        let path = Path::new(p);
        if path.file_name().is_none() {

            error!("rm: refusing to remove '{p}'");
            continue;
        }
        let result = match fs::symlink_metadata(path) {
            Ok(m) if m.is_dir() => {
                if !flags.contains('r') && !flags.contains('R') {
                    error!("rm: cannot remove '{p}': Is a directory");
                    continue;
                }
                fs::remove_dir_all(path)
            }
            Ok(_) => fs::remove_file(path),
            Err(e) => Err(e),
        };
        match result {
            Err(e) if e.kind() == io::ErrorKind::NotFound && flags.contains('f') => {}
            Err(e) => error!("rm: cannot remove '{p}': {}", reason(&e)),
            Ok(()) => {}
        }
    }
}

fn plan(cmd: &str, ops: &[String]) -> Vec<(String, PathBuf)> {
    if ops.len() < 2 {
        error!("{cmd}: missing file operand");
        return vec![];
    }
    let (dest, sources) = ops.split_last().unwrap();
    let dest_is_dir = Path::new(dest).is_dir();
    if sources.len() > 1 && !dest_is_dir {
        error!("{cmd}: target '{dest}' is not a directory");
        return vec![];
    }
    sources
        .iter()
        .map(|src| {
            let target = if dest_is_dir {
                Path::new(dest).join(Path::new(src).file_name().unwrap_or_default())
            } else {
                PathBuf::from(dest)
            };
            (src.clone(), target)
        })
        .collect()
}

fn copy_tree(src: &Path, dst: &Path) -> io::Result<()> {
    let meta = fs::symlink_metadata(src)?;
    if meta.is_dir() {
        fs::create_dir_all(dst)?;
        for entry in fs::read_dir(src)? {
            let entry = entry?;
            copy_tree(&entry.path(), &dst.join(entry.file_name()))?;
        }
        fs::set_permissions(dst, meta.permissions())
    } else if meta.file_type().is_symlink() {
        symlink(fs::read_link(src)?, dst)
    } else {
        fs::copy(src, dst).map(|_| ())
    }
}

fn same_file(a: &Path, b: &Path) -> bool {
    match (fs::metadata(a), fs::metadata(b)) {
        (Ok(x), Ok(y)) => x.dev() == y.dev() && x.ino() == y.ino(),
        _ => false,
    }
}

fn is_inside(src: &Path, dst: &Path) -> bool {
    let parent = dst.parent().filter(|p| !p.as_os_str().is_empty()).unwrap_or(Path::new("."));
    match (fs::canonicalize(src), fs::canonicalize(parent)) {
        (Ok(s), Ok(p)) => p.join(dst.file_name().unwrap_or_default()).starts_with(s),
        _ => false,
    }
}

pub fn cp(args: &[String]) {
    let (flags, ops) = split_flags(args);
    let recursive = flags.contains('r') || flags.contains('R');
    for (src, target) in plan("cp", &ops) {
        let (s, t) = (Path::new(&src), target.as_path());
        if !s.exists() {
            error!("cp: cannot stat '{src}': No such file or directory");
        } else if s.is_dir() && !recursive {
            error!("cp: -r not specified; omitting directory '{src}'");
        } else if s.is_dir() && is_inside(s, t) {
            error!("cp: cannot copy a directory, '{src}', into itself, '{}'", t.display());
        } else if same_file(s, t) {
            error!("cp: '{src}' and '{}' are the same file", t.display());
        } else if let Err(e) = copy_tree(s, t) {
            error!("cp: cannot copy '{src}' to '{}': {}", t.display(), reason(&e));
        }
    }
}

pub fn mv(args: &[String]) {
    let (_, ops) = split_flags(args);
    for (src, target) in plan("mv", &ops) {
        let (s, t) = (Path::new(&src), target.as_path());
        if same_file(s, t) {
            error!("mv: '{src}' and '{}' are the same file", t.display());
            continue;
        }
        let mut result = fs::rename(s, t);

        if matches!(&result, Err(e) if e.raw_os_error() == Some(18)) {
            result = copy_tree(s, t).and_then(|_| {
                if s.is_dir() { fs::remove_dir_all(s) } else { fs::remove_file(s) }
            });
        }
        if let Err(e) = result {
            error!("mv: cannot move '{src}' to '{}': {}", t.display(), reason(&e));
        }
    }
}
