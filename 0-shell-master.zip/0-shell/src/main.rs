macro_rules! say {
    ($out:expr, $($arg:tt)*) => {{ let _ = writeln!($out, $($arg)*); }};
}

macro_rules! error {
    ($($arg:tt)*) => { $crate::commands::print_error(&format!($($arg)*)) };
}

mod arith;
mod builtins;
mod commands;
mod editor;
mod expand;
mod jobs;
mod ls;
mod parser;
mod shell;
mod vars;

use parser::ParseError;
use shell::Flow;
use std::io::{self, IsTerminal};

extern "C" {
    fn signal(signum: i32, handler: usize) -> usize;
    fn write(fd: i32, buf: *const u8, count: usize) -> isize;
}
extern "C" fn on_sigint(_: i32) {
    unsafe { write(1, b"\n".as_ptr(), 1) };
}

fn prompt() -> String {
    if !io::stdin().is_terminal() {
        return "$ ".to_string();
    }
    let cwd = std::env::current_dir().map(|p| p.display().to_string()).unwrap_or_else(|_| "?".into());
    let shown = match std::env::var("HOME") {
        Ok(h) if !h.is_empty() && (cwd == h || cwd.starts_with(&format!("{h}/"))) => format!("~{}", &cwd[h.len()..]),
        _ => cwd,
    };
    format!("\x1b[1;32m{shown}\x1b[0m $ ")
}

fn read_command(editor: &mut editor::Editor, first: String) -> Option<parser::List> {
    let mut text = first;
    loop {
        match parser::parse(&text) {
            Ok(list) => return Some(list),
            Err(ParseError::Syntax(msg)) => {
                error!("0-shell: {msg}");
                vars::set_status(2);
                return None;
            }
            Err(ParseError::Incomplete) => match editor.read_line("> ") {
                Some(_) if editor.interrupted => return None,
                Some(more) => {
                    text.push('\n');
                    text.push_str(&more);
                }
                None => {
                    error!("0-shell: syntax error: unexpected end of file");
                    vars::set_status(2);
                    return None;
                }
            },
        }
    }
}

fn run_loop(editor: &mut editor::Editor) {
    loop {
        jobs::notify();
        match editor.read_line(&prompt()) {
            Some(line) => {
                if line.trim().is_empty() {
                    continue;
                }
                if let Some(list) = read_command(editor, line) {
                    if shell::exec_top(&list) == Flow::Exit {
                        break;
                    }
                }
            }
            None if jobs::confirm_exit() => break,
            None => {}
        }
    }
}

fn interactive_loop() {
    unsafe { signal(2, on_sigint as extern "C" fn(i32) as usize) };
    jobs::init();
    let mut editor = editor::Editor::new();
    run_loop(&mut editor);

    jobs::shutdown();
}

fn main() {
    let args: Vec<String> = std::env::args().collect();
    let code = match args.get(1).map(String::as_str) {
        None => {
            interactive_loop();
            vars::status()
        }
        Some("-c") => match args.get(2) {
            Some(cmd) => {
                let name = args.get(3).map(String::as_str).unwrap_or("0-shell");
                shell::run_command_string(cmd, name, args.get(4..).unwrap_or(&[]))
            }
            None => {
                eprintln!("0-shell: -c: option requires an argument");
                2
            }
        },
        Some(path) => shell::run_script(path, &args[2..]),
    };
    std::process::exit(code);
}
