use crate::commands::{reason, set_status, Io};
use crate::expand::glob_match;
use crate::vars;
use std::fs;
use std::io::{self, IsTerminal, Write};
use std::os::unix::fs::{FileTypeExt, MetadataExt};

extern "C" {
    fn access(path: *const std::os::raw::c_char, mode: i32) -> i32;
}

fn can(path: &str, mode: i32) -> bool {
    match std::ffi::CString::new(path) {
        Ok(c) => unsafe { access(c.as_ptr(), mode) == 0 },
        Err(_) => false,
    }
}

pub fn unescape(s: &str) -> (String, bool) {
    let chars: Vec<char> = s.chars().collect();
    let mut out = String::new();
    let mut i = 0;
    while i < chars.len() {
        if chars[i] != '\\' || i + 1 >= chars.len() {
            out.push(chars[i]);
            i += 1;
            continue;
        }
        i += 1;
        match chars[i] {
            'n' => out.push('\n'),
            't' => out.push('\t'),
            'r' => out.push('\r'),
            'a' => out.push('\x07'),
            'b' => out.push('\x08'),
            'e' | 'E' => out.push('\x1b'),
            'f' => out.push('\x0c'),
            'v' => out.push('\x0b'),
            '\\' => out.push('\\'),
            '"' => out.push('"'),
            'c' => return (out, true),
            '0'..='7' => {
                let mut v = 0u32;
                let mut n = 0;
                while n < 3 && i < chars.len() && ('0'..='7').contains(&chars[i]) {
                    v = v * 8 + chars[i].to_digit(8).unwrap();
                    i += 1;
                    n += 1;
                }
                out.push(char::from_u32(v).unwrap_or('?'));
                continue;
            }
            'x' => {
                let mut v = 0u32;
                let mut n = 0;
                while n < 2 && i + 1 < chars.len() && chars[i + 1].is_ascii_hexdigit() {
                    v = v * 16 + chars[i + 1].to_digit(16).unwrap();
                    i += 1;
                    n += 1;
                }
                if n == 0 {
                    out.push_str("\\x");
                } else {
                    out.push(char::from_u32(v).unwrap_or('?'));
                }
            }
            other => {
                out.push('\\');
                out.push(other);
            }
        }
        i += 1;
    }
    (out, false)
}

struct Test<'a> {
    a: &'a [String],
    p: usize,
    dbl: bool,
}

const UNARY: &[&str] = &["-n", "-z", "-e", "-f", "-d", "-r", "-w", "-x", "-s", "-L", "-h", "-b", "-c", "-p", "-S"];
const BINARY: &[&str] = &["=", "==", "!=", "-eq", "-ne", "-lt", "-le", "-gt", "-ge", "<", ">"];

impl<'a> Test<'a> {
    fn peek(&self) -> Option<&str> {
        self.a.get(self.p).map(String::as_str)
    }

    fn eat(&mut self, s: &str) -> bool {
        if self.peek() == Some(s) {
            self.p += 1;
            true
        } else {
            false
        }
    }

    fn or(&mut self) -> Result<bool, String> {
        let mut v = self.and()?;
        while self.eat("||") || self.eat("-o") {
            let r = self.and()?;
            v = v || r;
        }
        Ok(v)
    }

    fn and(&mut self) -> Result<bool, String> {
        let mut v = self.not()?;
        while self.eat("&&") || self.eat("-a") {
            let r = self.not()?;
            v = v && r;
        }
        Ok(v)
    }

    fn not(&mut self) -> Result<bool, String> {
        if self.peek() == Some("!") && self.a.len() - self.p > 1 {
            self.p += 1;
            return Ok(!self.not()?);
        }
        self.primary()
    }

    fn primary(&mut self) -> Result<bool, String> {
        if self.peek() == Some("(") {
            self.p += 1;
            let v = self.or()?;
            if !self.eat(")") {
                return Err("missing `)'".into());
            }
            return Ok(v);
        }
        let Some(first) = self.peek().map(str::to_string) else { return Err("argument expected".into()) };
        let second = self.a.get(self.p + 1).map(String::as_str);
        let third = self.a.get(self.p + 2).map(String::as_str);
        if let (Some(op), Some(rhs)) = (second, third) {
            if (BINARY.contains(&op) && !(op == "<" || op == ">")) || (self.dbl && (op == "<" || op == ">")) {
                self.p += 3;
                return self.binary(&first, op, rhs);
            }
        }
        if UNARY.contains(&first.as_str()) {
            if let Some(arg) = second {
                self.p += 2;
                return Ok(unary(&first, arg));
            }
        }
        self.p += 1;
        Ok(!first.is_empty())
    }

    fn binary(&self, l: &str, op: &str, r: &str) -> Result<bool, String> {
        let chars = |s: &str| s.chars().collect::<Vec<char>>();
        match op {
            "=" | "==" => Ok(if self.dbl { glob_match(&chars(r), &chars(l)) } else { l == r }),
            "!=" => Ok(if self.dbl { !glob_match(&chars(r), &chars(l)) } else { l != r }),
            "<" => Ok(l < r),
            ">" => Ok(l > r),
            _ => {
                let num = |s: &str| s.trim().parse::<i64>().map_err(|_| format!("{s}: integer expression expected"));
                let (a, b) = (num(l)?, num(r)?);
                Ok(match op {
                    "-eq" => a == b,
                    "-ne" => a != b,
                    "-lt" => a < b,
                    "-le" => a <= b,
                    "-gt" => a > b,
                    _ => a >= b,
                })
            }
        }
    }
}

fn unary(op: &str, arg: &str) -> bool {
    match op {
        "-n" => !arg.is_empty(),
        "-z" => arg.is_empty(),
        "-r" => can(arg, 4),
        "-w" => can(arg, 2),
        "-x" => can(arg, 1),
        "-e" => fs::metadata(arg).is_ok(),
        "-L" | "-h" => fs::symlink_metadata(arg).is_ok_and(|m| m.file_type().is_symlink()),
        _ => match fs::metadata(arg) {
            Err(_) => false,
            Ok(m) => match op {
                "-f" => m.is_file(),
                "-d" => m.is_dir(),
                "-s" => m.size() > 0,
                "-b" => m.file_type().is_block_device(),
                "-c" => m.file_type().is_char_device(),
                "-p" => m.file_type().is_fifo(),
                _ => m.file_type().is_socket(),
            },
        },
    }
}

pub fn test(kind: &str, args: &[String]) {
    let closer = match kind {
        "[" => Some("]"),
        "[[" => Some("]]"),
        _ => None,
    };
    let mut args = args;
    if let Some(c) = closer {
        if args.last().map(String::as_str) != Some(c) {
            error!("{kind}: missing `{c}'");
            return set_status(2);
        }
        args = &args[..args.len() - 1];
    }
    if args.is_empty() {
        return set_status(1);
    }
    let mut t = Test { a: args, p: 0, dbl: kind == "[[" };
    match t.or() {
        Ok(v) if t.p == args.len() => set_status(if v { 0 } else { 1 }),
        Ok(_) => {
            error!("{kind}: too many arguments");
            set_status(2)
        }
        Err(msg) => {
            error!("{kind}: {msg}");
            set_status(2)
        }
    }
}

pub fn read(args: &[String], io: &mut Io) {
    let (mut raw, mut prompt, mut names) = (false, None, Vec::new());
    let mut i = 0;
    while i < args.len() {
        match args[i].as_str() {
            "-r" => raw = true,
            "-s" => {}
            "-p" => {
                prompt = args.get(i + 1).cloned();
                i += 1;
            }
            a if a.starts_with('-') && a.len() > 1 && names.is_empty() => {
                error!("read: {a}: invalid option");
                return set_status(2);
            }
            a => names.push(a.to_string()),
        }
        i += 1;
    }
    for n in &names {
        if !vars::is_name(n) {
            error!("read: `{n}': not a valid identifier");
            return set_status(1);
        }
    }
    if let Some(p) = prompt {
        if io::stdin().is_terminal() {
            eprint!("{p}");
            let _ = io::stderr().flush();
        }
    }
    let mut bytes = Vec::new();
    let mut eof = false;
    loop {
        let mut b = [0u8; 1];
        match io.input.read(&mut b) {
            Ok(0) => {
                eof = true;
                break;
            }
            Ok(_) if b[0] == b'\n' => break,
            Ok(_) if b[0] == b'\\' && !raw => {
                let mut n = [0u8; 1];
                match io.input.read(&mut n) {
                    Ok(1) if n[0] == b'\n' => {}
                    Ok(1) => bytes.push(n[0]),
                    _ => {
                        eof = true;
                        break;
                    }
                }
            }
            Ok(_) => bytes.push(b[0]),
            Err(e) if e.kind() == io::ErrorKind::Interrupted => continue,
            Err(_) => {
                eof = true;
                break;
            }
        }
    }
    let line = String::from_utf8_lossy(&bytes).into_owned();
    if names.is_empty() {
        vars::set("REPLY", &line);
    } else {
        let mut rest = line.as_str();
        for (k, name) in names.iter().enumerate() {
            rest = rest.trim_start_matches([' ', '\t']);
            if k + 1 == names.len() {
                vars::set(name, rest.trim_end_matches([' ', '\t']));
            } else {
                let end = rest.find([' ', '\t']).unwrap_or(rest.len());
                vars::set(name, &rest[..end]);
                rest = &rest[end..];
            }
        }
    }
    set_status(if eof { 1 } else { 0 });
}

fn pad(s: String, width: usize, left: bool, zero: bool) -> String {
    let len = s.chars().count();
    if len >= width {
        return s;
    }
    let fill = width - len;
    if left {
        format!("{s}{}", " ".repeat(fill))
    } else if zero {
        let (sign, digits) = if s.starts_with('-') || s.starts_with('+') { s.split_at(1) } else { ("", s.as_str()) };
        format!("{sign}{}{digits}", "0".repeat(fill))
    } else {
        format!("{}{s}", " ".repeat(fill))
    }
}

fn format_once(fmt: &str, vals: &[String], used: &mut usize, out: &mut Vec<u8>) -> bool {
    let chars: Vec<char> = fmt.chars().collect();
    let mut i = 0;
    let mut literal = String::new();
    let flush_lit = |lit: &mut String, out: &mut Vec<u8>| {
        let (text, stop) = unescape(lit);
        out.extend_from_slice(text.as_bytes());
        lit.clear();
        stop
    };
    while i < chars.len() {
        if chars[i] != '%' {
            if chars[i] == '\\' && i + 1 < chars.len() {
                literal.push('\\');
                i += 1;
            }
            literal.push(chars[i]);
            i += 1;
            continue;
        }
        if flush_lit(&mut literal, out) {
            return true;
        }
        i += 1;
        let (mut left, mut zero, mut plus) = (false, false, false);
        while i < chars.len() && matches!(chars[i], '-' | '0' | '+' | ' ' | '#') {
            match chars[i] {
                '-' => left = true,
                '0' => zero = true,
                '+' => plus = true,
                _ => {}
            }
            i += 1;
        }
        let mut width = 0usize;
        while i < chars.len() && chars[i].is_ascii_digit() {
            width = width * 10 + chars[i].to_digit(10).unwrap() as usize;
            i += 1;
        }
        let mut prec = None;
        if i < chars.len() && chars[i] == '.' {
            i += 1;
            let mut p = 0usize;
            while i < chars.len() && chars[i].is_ascii_digit() {
                p = p * 10 + chars[i].to_digit(10).unwrap() as usize;
                i += 1;
            }
            prec = Some(p);
        }
        let Some(&conv) = chars.get(i) else {
            out.push(b'%');
            break;
        };
        i += 1;
        if conv == '%' {
            out.push(b'%');
            continue;
        }
        let arg_s = vals.get(*used).cloned().unwrap_or_default();
        *used += 1;
        let int = || -> i64 {
            let a = arg_s.trim();
            if let Some(c) = a.strip_prefix('\'').and_then(|r| r.chars().next()) {
                return c as i64;
            }
            let parsed = if let Some(h) = a.strip_prefix("0x") { i64::from_str_radix(h, 16).ok() } else { a.parse::<i64>().ok() };
            match parsed {
                Some(v) => v,
                None => {
                    if !a.is_empty() {
                        error!("printf: {a}: invalid number");
                    }
                    0
                }
            }
        };
        let text = match conv {
            's' => {
                let mut s = arg_s.clone();
                if let Some(p) = prec {
                    s = s.chars().take(p).collect();
                }
                pad(s, width, left, false)
            }
            'b' => pad(unescape(&arg_s).0, width, left, false),
            'c' => pad(arg_s.chars().next().map(String::from).unwrap_or_default(), width, left, false),
            'd' | 'i' => {
                let v = int();
                pad(if plus && v >= 0 { format!("+{v}") } else { v.to_string() }, width, left, zero)
            }
            'u' => pad((int() as u64).to_string(), width, left, zero),
            'x' => pad(format!("{:x}", int()), width, left, zero),
            'X' => pad(format!("{:X}", int()), width, left, zero),
            'o' => pad(format!("{:o}", int()), width, left, zero),
            other => {
                error!("printf: `{other}': invalid format character");
                return true;
            }
        };
        out.extend_from_slice(text.as_bytes());
    }
    flush_lit(&mut literal, out)
}

pub fn printf(args: &[String], io: &mut Io) {
    let Some(fmt) = args.first() else {
        error!("printf: usage: printf format [arguments]");
        return set_status(2);
    };
    let vals = &args[1..];
    let mut out = Vec::new();
    let mut used = 0;
    loop {
        let before = used;
        let stopped = format_once(fmt, vals, &mut used, &mut out);
        if stopped || used >= vals.len() || used == before {
            break;
        }
    }
    let _ = io.out.write_all(&out);
}

pub fn shift(args: &[String]) {
    let n = match args.first() {
        None => 1,
        Some(a) => match a.parse::<usize>() {
            Ok(n) => n,
            Err(_) => {
                error!("shift: {a}: numeric argument required");
                return set_status(1);
            }
        },
    };
    let mut pos = vars::positional();
    if n > pos.len() {
        return set_status(1);
    }
    pos.drain(..n);
    vars::set_positional(pos);
}

pub fn unset(args: &[String]) {
    for a in args.iter().filter(|a| !a.starts_with('-')) {
        if vars::is_name(a) {
            vars::unset(a);
        } else {
            error!("unset: `{a}': not a valid identifier");
        }
    }
}

pub fn local(args: &[String]) {
    for a in args {
        let (name, value) = match a.split_once('=') {
            Some((n, v)) => (n, Some(v)),
            None => (a.as_str(), None),
        };
        if !vars::is_name(name) {
            error!("local: `{a}': not a valid identifier");
            continue;
        }
        if !vars::declare_local(name) {
            error!("local: can only be used in a function");
            return;
        }
        match value {
            Some(v) => vars::set(name, v),
            None => vars::unset(name),
        }
    }
}

pub fn set(args: &[String], io: &mut Io) {
    if args.is_empty() {
        let mut all: Vec<_> = std::env::vars().collect();
        all.sort();
        for (k, v) in all {
            let _ = writeln!(io.out, "{k}={v}");
        }
        return;
    }
    if let Some(p) = args.iter().position(|a| a == "--") {
        vars::set_positional(args[p + 1..].to_vec());
    } else if !args[0].starts_with('-') && !args[0].starts_with('+') {
        vars::set_positional(args.to_vec());
    }
}

pub fn read_script(path: &str) -> Result<String, String> {
    match fs::read(path) {
        Ok(bytes) if bytes.contains(&0) => Err(format!("{path}: cannot execute binary file")),
        Ok(bytes) => Ok(String::from_utf8_lossy(&bytes).into_owned()),
        Err(e) => Err(format!("{path}: {}", reason(&e))),
    }
}
