use crate::vars;
use std::sync::atomic::{AtomicUsize, Ordering};

static DEPTH: AtomicUsize = AtomicUsize::new(0);

#[derive(Clone, Debug, PartialEq)]
enum Tok {
    Num(i64),
    Name(String),
    Op(&'static str),
}

const OPS: &[&str] = &[
    "<<=", ">>=", "**", "<<", ">>", "<=", ">=", "==", "!=", "&&", "||", "++", "--", "+=", "-=", "*=", "/=", "%=", "&=", "|=", "^=",
    "+", "-", "*", "/", "%", "<", ">", "=", "!", "~", "&", "|", "^", "?", ":", "(", ")", ",",
];

fn lex(src: &str) -> Result<Vec<Tok>, String> {
    let chars: Vec<char> = src.chars().collect();
    let mut toks = Vec::new();
    let mut i = 0;
    while i < chars.len() {
        let c = chars[i];
        if c.is_whitespace() {
            i += 1;
        } else if c.is_ascii_digit() {
            let start = i;
            while i < chars.len() && chars[i].is_ascii_alphanumeric() {
                i += 1;
            }
            let text: String = chars[start..i].iter().collect();
            let value = if let Some(hex) = text.strip_prefix("0x").or_else(|| text.strip_prefix("0X")) {
                i64::from_str_radix(hex, 16)
            } else {
                text.parse::<i64>()
            };
            toks.push(Tok::Num(value.map_err(|_| format!("{text}: value too great for base (error token is \"{text}\")"))?));
        } else if c.is_ascii_alphabetic() || c == '_' {
            let start = i;
            while i < chars.len() && (chars[i].is_ascii_alphanumeric() || chars[i] == '_') {
                i += 1;
            }
            toks.push(Tok::Name(chars[start..i].iter().collect()));
        } else {
            let rest: String = chars[i..].iter().take(3).collect();
            match OPS.iter().find(|op| rest.starts_with(**op)) {
                Some(op) => {
                    toks.push(Tok::Op(op));
                    i += op.len();
                }
                None => return Err(format!("syntax error: unexpected character '{c}'")),
            }
        }
    }
    Ok(toks)
}

#[derive(Debug)]
enum Expr {
    Num(i64),
    Var(String),
    Unary(&'static str, Box<Expr>),
    Binary(&'static str, Box<Expr>, Box<Expr>),
    Assign(&'static str, String, Box<Expr>),
    Step { name: String, delta: i64, post: bool },
    Cond(Box<Expr>, Box<Expr>, Box<Expr>),
}

struct Parser {
    toks: Vec<Tok>,
    pos: usize,
}

impl Parser {
    fn peek_op(&self) -> Option<&'static str> {
        match self.toks.get(self.pos) {
            Some(Tok::Op(op)) => Some(op),
            _ => None,
        }
    }

    fn eat(&mut self, op: &str) -> bool {
        if self.peek_op() == Some(op) {
            self.pos += 1;
            true
        } else {
            false
        }
    }

    fn comma(&mut self) -> Result<Expr, String> {
        let mut e = self.assignment()?;
        while self.eat(",") {
            let r = self.assignment()?;
            e = Expr::Binary(",", Box::new(e), Box::new(r));
        }
        Ok(e)
    }

    fn assignment(&mut self) -> Result<Expr, String> {
        if let (Some(Tok::Name(name)), Some(Tok::Op(op))) = (self.toks.get(self.pos), self.toks.get(self.pos + 1)) {
            if matches!(*op, "=" | "+=" | "-=" | "*=" | "/=" | "%=" | "&=" | "|=" | "^=" | "<<=" | ">>=") {
                let (name, op) = (name.clone(), *op);
                self.pos += 2;
                let rhs = self.assignment()?;
                return Ok(Expr::Assign(op, name, Box::new(rhs)));
            }
        }
        self.ternary()
    }

    fn ternary(&mut self) -> Result<Expr, String> {
        let cond = self.binary(0)?;
        if self.eat("?") {
            let a = self.assignment()?;
            if !self.eat(":") {
                return Err("syntax error: expected ':' in conditional expression".into());
            }
            let b = self.assignment()?;
            return Ok(Expr::Cond(Box::new(cond), Box::new(a), Box::new(b)));
        }
        Ok(cond)
    }

    fn binary(&mut self, level: usize) -> Result<Expr, String> {
        const LEVELS: &[&[&str]] = &[
            &["||"],
            &["&&"],
            &["|"],
            &["^"],
            &["&"],
            &["==", "!="],
            &["<", ">", "<=", ">="],
            &["<<", ">>"],
            &["+", "-"],
            &["*", "/", "%"],
        ];
        if level == LEVELS.len() {
            return self.power();
        }
        let mut left = self.binary(level + 1)?;
        while let Some(op) = self.peek_op() {
            let Some(found) = LEVELS[level].iter().find(|o| **o == op) else { break };
            self.pos += 1;
            let right = self.binary(level + 1)?;
            left = Expr::Binary(found, Box::new(left), Box::new(right));
        }
        Ok(left)
    }

    fn power(&mut self) -> Result<Expr, String> {
        let base = self.unary()?;
        if self.eat("**") {
            let exp = self.power()?;
            return Ok(Expr::Binary("**", Box::new(base), Box::new(exp)));
        }
        Ok(base)
    }

    fn unary(&mut self) -> Result<Expr, String> {
        for op in ["+", "-", "!", "~"] {
            if self.eat(op) {
                return Ok(Expr::Unary(op, Box::new(self.unary()?)));
            }
        }
        for (op, delta) in [("++", 1), ("--", -1)] {
            if self.eat(op) {
                return match self.toks.get(self.pos).cloned() {
                    Some(Tok::Name(name)) => {
                        self.pos += 1;
                        Ok(Expr::Step { name, delta, post: false })
                    }
                    _ => Err(format!("syntax error: {op} needs a variable")),
                };
            }
        }
        self.primary()
    }

    fn primary(&mut self) -> Result<Expr, String> {
        match self.toks.get(self.pos).cloned() {
            Some(Tok::Num(n)) => {
                self.pos += 1;
                Ok(Expr::Num(n))
            }
            Some(Tok::Name(name)) => {
                self.pos += 1;
                for (op, delta) in [("++", 1), ("--", -1)] {
                    if self.eat(op) {
                        return Ok(Expr::Step { name, delta, post: true });
                    }
                }
                Ok(Expr::Var(name))
            }
            Some(Tok::Op("(")) => {
                self.pos += 1;
                let e = self.comma()?;
                if !self.eat(")") {
                    return Err("syntax error: missing ')'".into());
                }
                Ok(e)
            }
            Some(Tok::Op(op)) => Err(format!("syntax error: unexpected '{op}'")),
            None => Err("syntax error: operand expected".into()),
        }
    }
}

fn var_value(name: &str) -> Result<i64, String> {
    match vars::get(name) {
        None => Ok(0),
        Some(v) if v.trim().is_empty() => Ok(0),
        Some(v) => match v.trim().parse::<i64>() {
            Ok(n) => Ok(n),
            Err(_) => {
                if DEPTH.fetch_add(1, Ordering::Relaxed) > 16 {
                    DEPTH.store(0, Ordering::Relaxed);
                    return Err("expression recursion level exceeded".into());
                }
                let r = eval(v.trim());
                DEPTH.fetch_sub(1, Ordering::Relaxed);
                r
            }
        },
    }
}

fn apply(op: &str, a: i64, b: i64) -> Result<i64, String> {
    Ok(match op {
        "+" => a.wrapping_add(b),
        "-" => a.wrapping_sub(b),
        "*" => a.wrapping_mul(b),
        "/" | "%" if b == 0 => return Err("division by 0".into()),
        "/" => a.wrapping_div(b),
        "%" => a.wrapping_rem(b),
        "**" => {
            if b < 0 {
                return Err("exponent less than 0".into());
            }
            a.wrapping_pow(b.min(u32::MAX as i64) as u32)
        }
        "<<" => a.wrapping_shl(b as u32),
        ">>" => a.wrapping_shr(b as u32),
        "<" => (a < b) as i64,
        ">" => (a > b) as i64,
        "<=" => (a <= b) as i64,
        ">=" => (a >= b) as i64,
        "==" => (a == b) as i64,
        "!=" => (a != b) as i64,
        "&" => a & b,
        "|" => a | b,
        "^" => a ^ b,
        "," => b,
        _ => return Err(format!("unknown operator {op}")),
    })
}

fn run(e: &Expr) -> Result<i64, String> {
    Ok(match e {
        Expr::Num(n) => *n,
        Expr::Var(name) => var_value(name)?,
        Expr::Unary(op, inner) => {
            let v = run(inner)?;
            match *op {
                "-" => v.wrapping_neg(),
                "!" => (v == 0) as i64,
                "~" => !v,
                _ => v,
            }
        }
        Expr::Binary("&&", l, r) => (run(l)? != 0 && run(r)? != 0) as i64,
        Expr::Binary("||", l, r) => (run(l)? != 0 || run(r)? != 0) as i64,
        Expr::Binary(op, l, r) => {
            let a = run(l)?;
            apply(op, a, run(r)?)?
        }
        Expr::Cond(c, a, b) => {
            if run(c)? != 0 {
                run(a)?
            } else {
                run(b)?
            }
        }
        Expr::Assign(op, name, rhs) => {
            let r = run(rhs)?;
            let value = if *op == "=" { r } else { apply(&op[..op.len() - 1], var_value(name)?, r)? };
            vars::set(name, &value.to_string());
            value
        }
        Expr::Step { name, delta, post } => {
            let old = var_value(name)?;
            let new = old.wrapping_add(*delta);
            vars::set(name, &new.to_string());
            if *post { old } else { new }
        }
    })
}

pub fn eval(src: &str) -> Result<i64, String> {
    if src.trim().is_empty() {
        return Ok(0);
    }
    let mut p = Parser { toks: lex(src)?, pos: 0 };
    let expr = p.comma()?;
    if p.pos != p.toks.len() {
        return Err(format!("syntax error in expression (error token is \"{:?}\")", p.toks[p.pos]));
    }
    run(&expr)
}
