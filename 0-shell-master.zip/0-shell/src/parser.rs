#[derive(Debug)]
pub enum ParseError {

    Incomplete,
    Syntax(String),
}

type Res<T> = Result<T, ParseError>;

fn syntax<T>(msg: impl Into<String>) -> Res<T> {
    Err(ParseError::Syntax(msg.into()))
}

#[derive(Debug, Clone, PartialEq)]
pub enum RedirOp {
    In,
    Out,
    Append,
    ErrOut,
    ErrAppend,
    ErrToOut,
    OutToErr,
}

#[derive(Debug, Clone)]
pub struct Redir {
    pub op: RedirOp,

    pub target: String,
}

#[derive(Debug, Clone)]
pub struct Simple {
    pub assigns: Vec<(String, String)>,
    pub words: Vec<String>,
    pub redirs: Vec<Redir>,
}

#[derive(Debug, Clone)]
pub enum Cmd {
    Simple(Simple),
    If { arms: Vec<(List, List)>, otherwise: Option<List> },
    While { cond: List, body: List, until: bool },
    For { var: String, items: Option<Vec<String>>, body: List },
    ArithFor { init: String, cond: String, step: String, body: List },
    Case { word: String, arms: Vec<(Vec<String>, List)> },
    Group(List),
    Subshell(List),
    Func { name: String, body: std::sync::Arc<Command> },
    Arith(String),
}

#[derive(Debug, Clone)]
pub struct Command {
    pub cmd: Cmd,

    pub redirs: Vec<Redir>,
}

#[derive(Debug, Clone)]
pub struct Pipeline {
    pub negate: bool,
    pub cmds: Vec<Command>,
    pub text: String,
}

#[derive(Debug, Clone)]
pub struct AndOr {
    pub first: Pipeline,

    pub rest: Vec<(bool, Pipeline)>,
    pub background: bool,
    pub text: String,
}

pub type List = Vec<AndOr>;

#[derive(Debug, Clone, PartialEq)]
enum Tok {
    Word(String),
    Op(&'static str),
    Newline,
    ArithFor(String),
    ArithCmd(String),
}

struct Token {
    tok: Tok,
    start: usize,
    end: usize,
}

pub fn skip_dollar_paren(s: &[char], i: usize) -> Res<usize> {
    let mut depth = 1;
    let mut j = i + 1;
    while j < s.len() {
        match s[j] {
            '(' => depth += 1,
            ')' => {
                depth -= 1;
                if depth == 0 {
                    return Ok(j + 1);
                }
            }
            '\\' => j += 1,
            '\'' => j = skip_single(s, j)? - 1,
            '"' => j = skip_double(s, j)? - 1,
            _ => {}
        }
        j += 1;
    }
    Err(ParseError::Incomplete)
}

fn skip_single(s: &[char], i: usize) -> Res<usize> {
    match s[i + 1..].iter().position(|&c| c == '\'') {
        Some(p) => Ok(i + p + 2),
        None => Err(ParseError::Incomplete),
    }
}

fn skip_backtick(s: &[char], i: usize) -> Res<usize> {
    let mut j = i + 1;
    while j < s.len() {
        match s[j] {
            '\\' => j += 1,
            '`' => return Ok(j + 1),
            _ => {}
        }
        j += 1;
    }
    Err(ParseError::Incomplete)
}

pub fn skip_braces(s: &[char], i: usize) -> Res<usize> {
    let mut depth = 1;
    let mut j = i + 1;
    while j < s.len() {
        match s[j] {
            '{' => depth += 1,
            '}' => {
                depth -= 1;
                if depth == 0 {
                    return Ok(j + 1);
                }
            }
            '\\' => j += 1,
            '\'' => j = skip_single(s, j)? - 1,
            '"' => j = skip_double(s, j)? - 1,
            _ => {}
        }
        j += 1;
    }
    Err(ParseError::Incomplete)
}

pub fn skip_double(s: &[char], i: usize) -> Res<usize> {
    let mut j = i + 1;
    while j < s.len() {
        match s[j] {
            '\\' => j += 1,
            '"' => return Ok(j + 1),
            '`' => j = skip_backtick(s, j)? - 1,
            '$' if s.get(j + 1) == Some(&'(') => j = skip_dollar_paren(s, j + 1)? - 1,
            '$' if s.get(j + 1) == Some(&'{') => j = skip_braces(s, j + 1)? - 1,
            _ => {}
        }
        j += 1;
    }
    Err(ParseError::Incomplete)
}

fn is_word_end(c: char) -> bool {
    c.is_whitespace() || matches!(c, ';' | '&' | '|' | '(' | ')' | '<' | '>')
}

const COMMAND_START_WORDS: &[&str] = &["then", "do", "else", "elif", "if", "while", "until", "{", "!"];

fn at_command_start(toks: &[Token]) -> bool {
    match toks.last().map(|t| &t.tok) {
        None | Some(Tok::Newline) | Some(Tok::Op(";" | "&" | "&&" | "||" | "|" | "(" | ";;" | ")")) => true,
        Some(Tok::Word(w)) => COMMAND_START_WORDS.contains(&w.as_str()),
        _ => false,
    }
}

fn arith_group(src: &[char], i: usize) -> Option<(String, usize)> {
    let mut depth = 0;
    let mut j = i;
    while j < src.len() {
        match src[j] {
            '(' => depth += 1,
            ')' => {
                depth -= 1;
                if depth == 0 {
                    return if j > i + 2 && src[j - 1] == ')' {
                        Some((src[i + 2..j - 1].iter().collect(), j + 1))
                    } else {
                        None
                    };
                }
            }
            _ => {}
        }
        j += 1;
    }
    None
}

fn lex(src: &[char]) -> Res<Vec<Token>> {
    let n = src.len();
    let mut toks: Vec<Token> = Vec::new();
    let mut i = 0;
    while i < n {
        let c = src[i];
        let start = i;
        let next = src.get(i + 1).copied();
        if c == ' ' || c == '\t' || c == '\r' {
            i += 1;
            continue;
        }
        if c == '\\' && next == Some('\n') {
            i += 2;
            continue;
        }
        if c == '#' {
            while i < n && src[i] != '\n' {
                i += 1;
            }
            continue;
        }

        let op: Option<(&'static str, usize)> = match c {
            '\n' => None,
            ';' if next == Some(';') => Some((";;", 2)),
            ';' => Some((";", 1)),
            '&' if next == Some('&') => Some(("&&", 2)),
            '&' => Some(("&", 1)),
            '|' if next == Some('|') => Some(("||", 2)),
            '|' => Some(("|", 1)),
            ')' => Some((")", 1)),
            '<' if next == Some('<') => return syntax("here-documents are not supported"),
            '<' => Some(("<", 1)),
            '>' => Some(redirect_out(src, i, 0)),
            '2' if next == Some('>') => {
                let (o, len) = redirect_out(src, i + 1, 1);
                Some((match o { ">" => "2>", ">>" => "2>>", other => other }, len))
            }
            '1' if next == Some('>') => Some(redirect_out(src, i + 1, 1)),
            _ => None,
        };
        if c == '\n' {
            toks.push(Token { tok: Tok::Newline, start, end: start + 1 });
            i += 1;
            continue;
        }
        if let Some((o, len)) = op {
            toks.push(Token { tok: Tok::Op(o), start, end: start + len });
            i += len;
            continue;
        }
        if c == '(' {
            let after_for = matches!(toks.last().map(|t| &t.tok), Some(Tok::Word(w)) if w == "for");
            if next == Some('(') && (after_for || at_command_start(&toks)) {
                if let Some((body, end)) = arith_group(src, i) {
                    let tok = if after_for { Tok::ArithFor(body) } else { Tok::ArithCmd(body) };
                    toks.push(Token { tok, start, end });
                    i = end;
                    continue;
                }
            }
            toks.push(Token { tok: Tok::Op("("), start, end: start + 1 });
            i += 1;
            continue;
        }
        let mut j = i;
        while j < n && !is_word_end(src[j]) {
            match src[j] {
                '\\' => {
                    if j + 1 >= n {
                        return Err(ParseError::Incomplete);
                    }
                    j += 2;
                }
                '\'' => j = skip_single(src, j)?,
                '"' => j = skip_double(src, j)?,
                '`' => j = skip_backtick(src, j)?,
                '$' if src.get(j + 1) == Some(&'(') => j = skip_dollar_paren(src, j + 1)?,
                '$' if src.get(j + 1) == Some(&'{') => j = skip_braces(src, j + 1)?,
                _ => j += 1,
            }
        }
        toks.push(Token { tok: Tok::Word(src[i..j].iter().collect()), start: i, end: j });
        i = j;
    }
    Ok(toks)
}

fn redirect_out(src: &[char], at: usize, prefix: usize) -> (&'static str, usize) {
    let after = src.get(at + 1).copied();
    let digit = src.get(at + 2).copied();
    if after == Some('&') && digit == Some('1') && prefix == 1 && src[at - 1] == '2' {
        return ("2>&1", prefix + 3);
    }
    if after == Some('&') && digit == Some('2') && prefix == 0 {
        return (">&2", 3);
    }
    if after == Some('&') && digit == Some('2') && prefix == 1 && src[at - 1] == '1' {
        return (">&2", 4);
    }
    if after == Some('>') {
        return (">>", prefix + 2);
    }
    (">", prefix + 1)
}

struct Parser<'a> {
    toks: Vec<Token>,
    pos: usize,
    src: &'a [char],
}

fn describe(tok: &Tok) -> String {
    match tok {
        Tok::Word(w) => w.clone(),
        Tok::Op(o) => o.to_string(),
        Tok::Newline => "newline".to_string(),
        Tok::ArithFor(_) | Tok::ArithCmd(_) => "((".to_string(),
    }
}

impl<'a> Parser<'a> {
    fn peek(&self) -> Option<&Tok> {
        self.toks.get(self.pos).map(|t| &t.tok)
    }

    fn peek_at(&self, off: usize) -> Option<&Tok> {
        self.toks.get(self.pos + off).map(|t| &t.tok)
    }

    fn is_word(&self, w: &str) -> bool {
        matches!(self.peek(), Some(Tok::Word(x)) if x == w)
    }

    fn is_op(&self, o: &str) -> bool {
        matches!(self.peek(), Some(Tok::Op(x)) if *x == o)
    }

    fn unexpected<T>(&self) -> Res<T> {
        match self.peek() {
            None => Err(ParseError::Incomplete),
            Some(t) => syntax(format!("syntax error near unexpected token `{}'", describe(t))),
        }
    }

    fn expect_word(&mut self, w: &str) -> Res<()> {
        if self.is_word(w) {
            self.pos += 1;
            Ok(())
        } else {
            self.unexpected()
        }
    }

    fn skip_newlines(&mut self) {
        while matches!(self.peek(), Some(Tok::Newline)) {
            self.pos += 1;
        }
    }

    fn skip_separators(&mut self) {
        while matches!(self.peek(), Some(Tok::Newline) | Some(Tok::Op(";"))) {
            self.pos += 1;
        }
    }

    fn text(&self, from: usize, to: usize) -> String {
        self.src[from..to].iter().collect::<String>().trim().to_string()
    }

    fn at_stop(&self, stops: &[&str]) -> bool {
        match self.peek() {
            Some(Tok::Word(w)) => stops.contains(&w.as_str()),
            Some(Tok::Op(")")) | Some(Tok::Op(";;")) => true,
            _ => false,
        }
    }

    fn parse_list(&mut self, stops: &[&str]) -> Res<List> {
        let mut list = Vec::new();
        loop {
            self.skip_separators();
            if self.peek().is_none() || self.at_stop(stops) {
                return Ok(list);
            }
            let mut ao = self.parse_andor()?;
            match self.peek() {
                Some(Tok::Op("&")) => {
                    ao.background = true;
                    self.pos += 1;
                }
                Some(Tok::Op(";")) | Some(Tok::Newline) => self.pos += 1,
                _ => {}
            }
            list.push(ao);
            if !(self.peek().is_none() || self.at_stop(stops) || matches!(self.toks[self.pos - 1].tok, Tok::Op(";" | "&") | Tok::Newline)) {
                return self.unexpected();
            }
        }
    }

    fn parse_andor(&mut self) -> Res<AndOr> {
        let start = self.toks[self.pos].start;
        let first = self.parse_pipeline()?;
        let mut rest = Vec::new();
        while let Some(Tok::Op(op @ ("&&" | "||"))) = self.peek() {
            let and = *op == "&&";
            self.pos += 1;
            self.skip_newlines();
            rest.push((and, self.parse_pipeline()?));
        }
        let end = self.toks[self.pos - 1].end;
        Ok(AndOr { first, rest, background: false, text: self.text(start, end) })
    }

    fn parse_pipeline(&mut self) -> Res<Pipeline> {
        let start = self.toks.get(self.pos).map(|t| t.start).unwrap_or(0);
        let mut negate = false;
        while self.is_word("!") {
            negate = !negate;
            self.pos += 1;
        }
        let mut cmds = vec![self.parse_command()?];
        while self.is_op("|") {
            self.pos += 1;
            self.skip_newlines();
            cmds.push(self.parse_command()?);
        }
        let end = self.toks[self.pos - 1].end;
        Ok(Pipeline { negate, cmds, text: self.text(start, end) })
    }

    fn parse_redirs(&mut self) -> Res<Vec<Redir>> {
        let mut redirs = Vec::new();
        while let Some(Tok::Op(op)) = self.peek() {
            let op = match *op {
                "<" => RedirOp::In,
                ">" => RedirOp::Out,
                ">>" => RedirOp::Append,
                "2>" => RedirOp::ErrOut,
                "2>>" => RedirOp::ErrAppend,
                "2>&1" => RedirOp::ErrToOut,
                ">&2" => RedirOp::OutToErr,
                _ => break,
            };
            self.pos += 1;
            if matches!(op, RedirOp::ErrToOut | RedirOp::OutToErr) {
                redirs.push(Redir { op, target: String::new() });
                continue;
            }
            match self.peek() {
                Some(Tok::Word(w)) => {
                    redirs.push(Redir { op, target: w.clone() });
                    self.pos += 1;
                }
                None => return Err(ParseError::Incomplete),
                Some(_) => return syntax("syntax error: missing file name after redirection"),
            }
        }
        Ok(redirs)
    }

    fn parse_command(&mut self) -> Res<Command> {
        let Some(tok) = self.peek().cloned() else { return Err(ParseError::Incomplete) };
        let cmd = match &tok {
            Tok::ArithCmd(expr) => {
                self.pos += 1;
                Cmd::Arith(expr.clone())
            }
            Tok::ArithFor(spec) => {
                self.pos += 1;
                self.parse_arith_for(spec)?
            }
            Tok::Op("(") => {
                self.pos += 1;
                let body = self.parse_list(&[])?;
                if !self.is_op(")") {
                    return self.unexpected();
                }
                self.pos += 1;
                Cmd::Subshell(body)
            }
            Tok::Word(w) => match w.as_str() {
                "if" => self.parse_if()?,
                "while" | "until" => self.parse_while(w == "until")?,
                "for" => self.parse_for()?,
                "case" => self.parse_case()?,
                "{" => {
                    self.pos += 1;
                    let body = self.parse_list(&["}"])?;
                    self.expect_word("}")?;
                    Cmd::Group(body)
                }
                "function" => self.parse_function_keyword()?,
                "then" | "do" | "done" | "fi" | "else" | "elif" | "esac" | "}" => return self.unexpected(),
                name if crate::vars::is_name(name) && self.peek_at(1) == Some(&Tok::Op("(")) && self.peek_at(2) == Some(&Tok::Op(")")) => {
                    let name = name.to_string();
                    self.pos += 3;
                    self.parse_function_body(name)?
                }
                _ => return self.parse_simple(),
            },
            _ => return self.parse_simple(),
        };
        let redirs = if matches!(cmd, Cmd::Func { .. }) { Vec::new() } else { self.parse_redirs()? };
        Ok(Command { cmd, redirs })
    }

    fn parse_function_keyword(&mut self) -> Res<Cmd> {
        self.pos += 1;
        let Some(Tok::Word(name)) = self.peek().cloned() else { return self.unexpected() };
        self.pos += 1;
        if self.is_op("(") && self.peek_at(1) == Some(&Tok::Op(")")) {
            self.pos += 2;
        }
        self.parse_function_body(name)
    }

    fn parse_function_body(&mut self, name: String) -> Res<Cmd> {
        self.skip_newlines();
        let body = self.parse_command()?;
        if !matches!(body.cmd, Cmd::Group(_) | Cmd::Subshell(_) | Cmd::If { .. } | Cmd::While { .. } | Cmd::For { .. } | Cmd::ArithFor { .. } | Cmd::Case { .. }) {
            return syntax("syntax error: function body must be a compound command");
        }
        Ok(Cmd::Func { name, body: std::sync::Arc::new(body) })
    }

    fn parse_if(&mut self) -> Res<Cmd> {
        self.pos += 1;
        let mut arms = Vec::new();
        let mut otherwise = None;
        loop {
            let cond = self.parse_list(&["then"])?;
            if cond.is_empty() {
                return self.unexpected();
            }
            self.expect_word("then")?;
            let body = self.parse_list(&["elif", "else", "fi"])?;
            arms.push((cond, body));
            if self.is_word("elif") {
                self.pos += 1;
            } else if self.is_word("else") {
                self.pos += 1;
                otherwise = Some(self.parse_list(&["fi"])?);
                self.expect_word("fi")?;
                break;
            } else {
                self.expect_word("fi")?;
                break;
            }
        }
        Ok(Cmd::If { arms, otherwise })
    }

    fn parse_while(&mut self, until: bool) -> Res<Cmd> {
        self.pos += 1;
        let cond = self.parse_list(&["do"])?;
        self.expect_word("do")?;
        let body = self.parse_list(&["done"])?;
        self.expect_word("done")?;
        Ok(Cmd::While { cond, body, until })
    }

    fn parse_for(&mut self) -> Res<Cmd> {
        self.pos += 1;
        if let Some(Tok::ArithFor(spec)) = self.peek().cloned() {
            self.pos += 1;
            return self.parse_arith_for(&spec);
        }
        let Some(Tok::Word(var)) = self.peek().cloned() else { return self.unexpected() };
        if !crate::vars::is_name(&var) {
            return syntax(format!("`{var}': not a valid identifier"));
        }
        self.pos += 1;
        self.skip_newlines();
        let mut items = None;
        if self.is_word("in") {
            self.pos += 1;
            let mut words = Vec::new();
            while let Some(Tok::Word(w)) = self.peek() {
                words.push(w.clone());
                self.pos += 1;
            }
            items = Some(words);
        }
        self.skip_separators();
        self.expect_word("do")?;
        let body = self.parse_list(&["done"])?;
        self.expect_word("done")?;
        Ok(Cmd::For { var, items, body })
    }

    fn parse_arith_for(&mut self, spec: &str) -> Res<Cmd> {
        let parts: Vec<&str> = spec.split(';').collect();
        if parts.len() != 3 {
            return syntax("syntax error: expected `for ((init; condition; step))'");
        }
        self.skip_separators();
        self.expect_word("do")?;
        let body = self.parse_list(&["done"])?;
        self.expect_word("done")?;
        Ok(Cmd::ArithFor { init: parts[0].trim().into(), cond: parts[1].trim().into(), step: parts[2].trim().into(), body })
    }

    fn parse_case(&mut self) -> Res<Cmd> {
        self.pos += 1;
        let Some(Tok::Word(word)) = self.peek().cloned() else { return self.unexpected() };
        self.pos += 1;
        self.skip_newlines();
        self.expect_word("in")?;
        let mut arms = Vec::new();
        loop {
            self.skip_separators();
            if self.is_word("esac") {
                self.pos += 1;
                break;
            }
            if self.is_op("(") {
                self.pos += 1;
            }
            let mut patterns = Vec::new();
            loop {
                match self.peek().cloned() {
                    Some(Tok::Word(w)) => {
                        patterns.push(w);
                        self.pos += 1;
                    }
                    None => return Err(ParseError::Incomplete),
                    _ => return self.unexpected(),
                }
                if self.is_op("|") {
                    self.pos += 1;
                } else {
                    break;
                }
            }
            if !self.is_op(")") {
                return self.unexpected();
            }
            self.pos += 1;
            let body = self.parse_list(&["esac"])?;
            if self.is_op(";;") {
                self.pos += 1;
            }
            arms.push((patterns, body));
        }
        Ok(Cmd::Case { word, arms })
    }

    fn parse_simple(&mut self) -> Res<Command> {
        let mut assigns = Vec::new();
        let mut words: Vec<String> = Vec::new();
        let mut redirs = Vec::new();
        let in_test = |w: &Vec<String>| w.first().map(String::as_str) == Some("[[");
        loop {
            let Some(tok) = self.peek().cloned() else { break };
            match tok {
                Tok::Word(w) => {
                    if words.is_empty() && assigns_ok(&w) {
                        let (name, value) = w.split_once('=').unwrap();
                        assigns.push((name.to_string(), value.to_string()));
                    } else {
                        let done = w == "]]" && in_test(&words);
                        words.push(w);
                        if done {
                            self.pos += 1;
                            redirs.extend(self.parse_redirs()?);
                            break;
                        }
                    }
                    self.pos += 1;
                }
                Tok::Op(op) if in_test(&words) && matches!(op, "&&" | "||" | "(" | ")" | "<" | ">") => {
                    words.push(op.to_string());
                    self.pos += 1;
                }
                Tok::Op("<" | ">" | ">>" | "2>" | "2>>" | "2>&1" | ">&2") => redirs.extend(self.parse_redirs()?),
                _ => break,
            }
        }
        if in_test(&words) && words.last().map(String::as_str) != Some("]]") {
            return Err(ParseError::Incomplete);
        }
        if words.is_empty() && assigns.is_empty() && redirs.is_empty() {
            return self.unexpected();
        }
        Ok(Command { cmd: Cmd::Simple(Simple { assigns, words, redirs }), redirs: Vec::new() })
    }
}

fn assigns_ok(word: &str) -> bool {
    word.split_once('=').is_some_and(|(name, _)| crate::vars::is_name(name))
}

pub fn parse(text: &str) -> Result<List, ParseError> {
    let src: Vec<char> = text.chars().collect();
    let toks = lex(&src)?;
    let mut p = Parser { toks, pos: 0, src: &src };
    let list = p.parse_list(&[])?;
    if p.pos < p.toks.len() {
        return p.unexpected();
    }
    Ok(list)
}
