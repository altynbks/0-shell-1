use crate::parser::Command;
use std::collections::HashMap;
use std::sync::atomic::{AtomicI32, Ordering};
use std::sync::{Arc, Mutex, MutexGuard};

static STATUS: AtomicI32 = AtomicI32::new(0);

struct State {
    positional: Vec<String>,
    script_name: String,
    functions: HashMap<String, Arc<Command>>,

    frames: Vec<Vec<(String, Option<String>)>>,
}

static STATE: Mutex<Option<State>> = Mutex::new(None);

fn state() -> MutexGuard<'static, Option<State>> {
    STATE.lock().unwrap_or_else(|e| e.into_inner())
}

fn with<R>(f: impl FnOnce(&mut State) -> R) -> R {
    let mut guard = state();
    let st = guard.get_or_insert_with(|| State {
        positional: Vec::new(),
        script_name: "0-shell".to_string(),
        functions: HashMap::new(),
        frames: Vec::new(),
    });
    f(st)
}

pub fn status() -> i32 {
    STATUS.load(Ordering::Relaxed)
}

pub fn set_status(code: i32) {
    STATUS.store(code, Ordering::Relaxed);
}

pub fn is_name(s: &str) -> bool {
    let mut chars = s.chars();
    matches!(chars.next(), Some(c) if c.is_ascii_alphabetic() || c == '_') && chars.all(|c| c.is_ascii_alphanumeric() || c == '_')
}

pub fn get(name: &str) -> Option<String> {
    if !is_name(name) {
        return None;
    }
    std::env::var(name).ok()
}

pub fn set(name: &str, value: &str) {
    if is_name(name) {
        std::env::set_var(name, value.replace('\0', ""));
    }
}

pub fn unset(name: &str) {
    if is_name(name) {
        std::env::remove_var(name);
    }
}

pub fn positional() -> Vec<String> {
    with(|s| s.positional.clone())
}

pub fn set_positional(args: Vec<String>) -> Vec<String> {
    with(|s| std::mem::replace(&mut s.positional, args))
}

pub fn script_name() -> String {
    with(|s| s.script_name.clone())
}

pub fn set_script_name(name: &str) -> String {
    with(|s| std::mem::replace(&mut s.script_name, name.to_string()))
}

pub fn define_function(name: &str, body: Arc<Command>) {
    with(|s| {
        s.functions.insert(name.to_string(), body);
    });
}

pub fn function(name: &str) -> Option<Arc<Command>> {
    with(|s| s.functions.get(name).cloned())
}

pub fn function_depth() -> usize {
    with(|s| s.frames.len())
}

pub fn push_frame() {
    with(|s| s.frames.push(Vec::new()));
}

pub fn pop_frame() {
    let saved = with(|s| s.frames.pop().unwrap_or_default());
    for (name, old) in saved.into_iter().rev() {
        match old {
            Some(v) => set(&name, &v),
            None => unset(&name),
        }
    }
}

pub fn declare_local(name: &str) -> bool {
    let old = get(name);
    with(|s| match s.frames.last_mut() {
        Some(frame) => {
            if !frame.iter().any(|(n, _)| n == name) {
                frame.push((name.to_string(), old));
            }
            true
        }
        None => false,
    })
}
