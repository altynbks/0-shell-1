use crate::parser::{skip_braces, skip_dollar_paren, skip_double};
use crate::{arith, jobs, vars};
use std::sync::atomic::{AtomicI32, Ordering};

static SUBST_STATUS: AtomicI32 = AtomicI32::new(-1);

pub fn take_subst_status() -> Option<i32> {
    let s = SUBST_STATUS.swap(-1, Ordering::Relaxed);
    (s >= 0).then_some(s)
}

pub fn fields(raw: &str) -> Vec<String> {
    run(raw, true)
}

pub fn string(raw: &str) -> String {
    run(raw, false).join(" ")
}

struct Exp {
    out: Vec<String>,
    cur: String,
    has: bool,
    split: bool,
}

impl Exp {
    fn lit(&mut self, s: &str) {
        self.cur.push_str(s);
        self.has = true;
    }

    fn flush(&mut self) {
        if self.has {
            self.out.push(std::mem::take(&mut self.cur));
            self.has = false;
        }
    }

    fn value(&mut self, v: &str, quoted: bool) {
        if quoted || !self.split {
            if !v.is_empty() || quoted {
                self.lit(v);
            }
            return;
        }
        for c in v.chars() {
            if c.is_whitespace() {
                self.flush();
            } else {
                self.cur.push(c);
                self.has = true;
            }
        }
    }

    fn finish(mut self) -> Vec<String> {
        if self.has || (!self.split && self.out.is_empty()) {
            self.out.push(std::mem::take(&mut self.cur));
        }
        self.out
    }
}

fn home() -> String {
    std::env::var("HOME").unwrap_or_else(|_| "~".to_string())
}

fn run(raw: &str, split: bool) -> Vec<String> {
    let c: Vec<char> = raw.chars().collect();
    let mut e = Exp { out: Vec::new(), cur: String::new(), has: false, split };
    let mut i = 0;
    if c.first() == Some(&'~') && (c.len() == 1 || c[1] == '/') {
        e.lit(&home());
        i = 1;
    }
    while i < c.len() {
        match c[i] {
            '\\' => {
                if let Some(&next) = c.get(i + 1) {
                    e.lit(&next.to_string());
                }
                i += 2;
            }
            '\'' => {
                let end = c[i + 1..].iter().position(|&x| x == '\'').map_or(c.len(), |p| i + 1 + p);
                let text: String = c[i + 1..end].iter().collect();
                e.lit(&text);
                i = end + 1;
            }
            '"' => i = double_quoted(&mut e, &c, i),
            '$' => i = dollar(&mut e, &c, i, false),
            '`' => i = backtick(&mut e, &c, i, false),
            ch => {
                e.lit(&ch.to_string());
                i += 1;
            }
        }
    }
    e.finish()
}

fn double_quoted(e: &mut Exp, c: &[char], start: usize) -> usize {
    let end = skip_double(c, start).map(|x| x - 1).unwrap_or(c.len());
    let only_at = c[start..].starts_with(&['"', '$', '@', '"']);
    if !only_at {
        e.has = true;
    }
    let mut i = start + 1;
    while i < end {
        match c[i] {
            '\\' if matches!(c.get(i + 1), Some('$' | '`' | '"' | '\\' | '\n')) => {
                if c[i + 1] != '\n' {
                    e.lit(&c[i + 1].to_string());
                }
                i += 2;
            }
            '$' => i = dollar(e, &c[..end], i, true),
            '`' => i = backtick(e, &c[..end], i, true),
            ch => {
                e.lit(&ch.to_string());
                i += 1;
            }
        }
    }
    end + 1
}

fn substitute(cmd: &str) -> String {
    let (bytes, status) = jobs::capture(|| crate::shell::run_source(cmd));
    SUBST_STATUS.store(status, Ordering::Relaxed);
    let mut text = String::from_utf8_lossy(&bytes).into_owned();
    while text.ends_with('\n') {
        text.pop();
    }
    text
}

fn backtick(e: &mut Exp, c: &[char], i: usize, quoted: bool) -> usize {
    let mut j = i + 1;
    let mut body = String::new();
    while j < c.len() && c[j] != '`' {
        if c[j] == '\\' && matches!(c.get(j + 1), Some('`' | '\\' | '$')) {
            j += 1;
        }
        body.push(c[j]);
        j += 1;
    }
    let out = substitute(&body);
    e.value(&out, quoted);
    j + 1
}

fn positional_join() -> String {
    vars::positional().join(" ")
}

fn lookup(name: &str) -> Option<String> {
    match name {
        "?" => Some(vars::status().to_string()),
        "#" => Some(vars::positional().len().to_string()),
        "$" => Some(std::process::id().to_string()),
        "!" => Some(jobs::last_bg_pid().to_string()).filter(|p| p != "0"),
        "0" => Some(vars::script_name()),
        "@" | "*" => Some(positional_join()),
        "-" => Some(String::new()),
        _ if !name.is_empty() && name.chars().all(|ch| ch.is_ascii_digit()) => {
            let n: usize = name.parse().ok()?;
            vars::positional().get(n - 1).cloned()
        }
        _ => vars::get(name),
    }
}

fn dollar(e: &mut Exp, c: &[char], i: usize, quoted: bool) -> usize {
    let Some(&next) = c.get(i + 1) else {
        e.lit("$");
        return i + 1;
    };
    match next {
        '(' => {
            let Ok(end) = skip_dollar_paren(c, i + 1) else {
                e.lit("$");
                return i + 1;
            };
            if c.get(i + 2) == Some(&'(') && end >= i + 5 && c[end - 2] == ')' {
                let expr_raw: String = c[i + 3..end - 2].iter().collect();
                let expr = string(&expr_raw);
                match arith::eval(&expr) {
                    Ok(v) => e.value(&v.to_string(), quoted),
                    Err(msg) => {
                        error!("0-shell: {expr}: {msg}");
                        e.value("0", quoted);
                    }
                }
            } else {
                let body: String = c[i + 2..end - 1].iter().collect();
                let out = substitute(&body);
                e.value(&out, quoted);
            }
            end
        }
        '{' => {
            let Ok(end) = skip_braces(c, i + 1) else {
                e.lit("$");
                return i + 1;
            };
            let body: String = c[i + 2..end - 1].iter().collect();
            let out = parameter(&body);
            e.value(&out, quoted);
            end
        }
        '@' if quoted && e.split => {
            let args = vars::positional();
            let last = args.len().saturating_sub(1);
            for (k, a) in args.iter().enumerate() {
                e.lit(a);
                if k != last {
                    e.flush();
                }
            }
            i + 2
        }
        '@' | '*' | '#' | '?' | '$' | '!' | '-' => {
            let v = lookup(&next.to_string()).unwrap_or_default();
            e.value(&v, quoted);
            i + 2
        }
        d if d.is_ascii_digit() => {
            let v = lookup(&d.to_string()).unwrap_or_default();
            e.value(&v, quoted);
            i + 2
        }
        a if a.is_ascii_alphabetic() || a == '_' => {
            let mut j = i + 1;
            while j < c.len() && (c[j].is_ascii_alphanumeric() || c[j] == '_') {
                j += 1;
            }
            let name: String = c[i + 1..j].iter().collect();
            let v = lookup(&name).unwrap_or_default();
            e.value(&v, quoted);
            j
        }
        _ => {
            e.lit("$");
            i + 1
        }
    }
}

fn parameter(body: &str) -> String {
    let chars: Vec<char> = body.chars().collect();
    if chars.first() == Some(&'#') && chars.len() > 1 {
        let name: String = chars[1..].iter().collect();
        return lookup(&name).unwrap_or_default().chars().count().to_string();
    }
    let mut n = 0;
    if chars.first().is_some_and(|c| c.is_ascii_digit()) {
        while n < chars.len() && chars[n].is_ascii_digit() {
            n += 1;
        }
    } else if chars.first().is_some_and(|c| matches!(c, '@' | '*' | '#' | '?' | '$' | '!')) {
        n = 1;
    } else {
        while n < chars.len() && (chars[n].is_ascii_alphanumeric() || chars[n] == '_') {
            n += 1;
        }
    }
    let name: String = chars[..n].iter().collect();
    let rest: String = chars[n..].iter().collect();
    let value = lookup(&name);
    let unset_or_empty = value.as_deref().map_or(true, str::is_empty);
    let val = value.clone().unwrap_or_default();

    let (op, word) = match rest.as_str() {
        "" => return val,
        r if r.starts_with("##") || r.starts_with("%%") || r.starts_with("//") => (&r[..2], &r[2..]),
        r if r.starts_with(":-") || r.starts_with(":=") || r.starts_with(":+") || r.starts_with(":?") => (&r[..2], &r[2..]),
        r => (&r[..1], &r[1..]),
    };
    match op {
        ":-" => if unset_or_empty { string(word) } else { val },
        "-" => if value.is_none() { string(word) } else { val },
        ":=" | "=" => {
            if unset_or_empty && (op == ":=" || value.is_none()) {
                let w = string(word);
                vars::set(&name, &w);
                w
            } else {
                val
            }
        }
        ":+" => if unset_or_empty { String::new() } else { string(word) },
        "+" => if value.is_some() { string(word) } else { String::new() },
        ":?" | "?" => {
            if unset_or_empty && (op == ":?" || value.is_none()) {
                let msg = if word.is_empty() { "parameter null or not set".to_string() } else { string(word) };
                error!("0-shell: {name}: {msg}");
            }
            val
        }
        "#" | "##" => {
            let pat: Vec<char> = string(word).chars().collect();
            let v: Vec<char> = val.chars().collect();
            let cuts: Vec<usize> = (0..=v.len()).collect();
            let found = if op == "#" { cuts.iter().find(|&&k| glob_match(&pat, &v[..k])) } else { cuts.iter().rev().find(|&&k| glob_match(&pat, &v[..k])) };
            match found {
                Some(&k) => v[k..].iter().collect(),
                None => val,
            }
        }
        "%" | "%%" => {
            let pat: Vec<char> = string(word).chars().collect();
            let v: Vec<char> = val.chars().collect();
            let cuts: Vec<usize> = (0..=v.len()).collect();
            let found = if op == "%" { cuts.iter().rev().find(|&&k| glob_match(&pat, &v[k..])) } else { cuts.iter().find(|&&k| glob_match(&pat, &v[k..])) };
            match found {
                Some(&k) => v[..k].iter().collect(),
                None => val,
            }
        }
        "/" | "//" => {
            let (pat, rep) = word.split_once('/').unwrap_or((word, ""));
            let (pat, rep) = (string(pat), string(rep));
            if pat.is_empty() {
                val
            } else if op == "//" {
                val.replace(&pat, &rep)
            } else {
                val.replacen(&pat, &rep, 1)
            }
        }
        ":" => {
            let (off, len) = match word.split_once(':') {
                Some((o, l)) => (o, Some(l)),
                None => (word, None),
            };
            let v: Vec<char> = val.chars().collect();
            let eval = |s: &str| arith::eval(&string(s)).unwrap_or(0);
            let mut start = eval(off);
            if start < 0 {
                start += v.len() as i64;
            }
            let start = start.clamp(0, v.len() as i64) as usize;
            let end = match len {
                Some(l) => {
                    let l = eval(l);
                    if l < 0 { (v.len() as i64 + l).max(start as i64) as usize } else { (start + l as usize).min(v.len()) }
                }
                None => v.len(),
            };
            v[start..end].iter().collect()
        }
        _ => {
            error!("0-shell: ${{{body}}}: bad substitution");
            String::new()
        }
    }
}

pub fn glob_match(pat: &[char], s: &[char]) -> bool {
    match pat.first() {
        None => s.is_empty(),
        Some('*') => (0..=s.len()).any(|k| glob_match(&pat[1..], &s[k..])),
        Some('?') => !s.is_empty() && glob_match(&pat[1..], &s[1..]),
        Some('[') => {
            let Some(ch) = s.first() else { return false };
            let Some(close) = pat.iter().skip(2).position(|&c| c == ']').map(|p| p + 2) else {
                return *ch == '[' && glob_match(&pat[1..], &s[1..]);
            };
            let mut set = &pat[1..close];
            let negate = matches!(set.first(), Some('!' | '^'));
            if negate {
                set = &set[1..];
            }
            let mut hit = false;
            let mut k = 0;
            while k < set.len() {
                if k + 2 < set.len() && set[k + 1] == '-' {
                    hit |= set[k] <= *ch && *ch <= set[k + 2];
                    k += 3;
                } else {
                    hit |= set[k] == *ch;
                    k += 1;
                }
            }
            hit != negate && glob_match(&pat[close + 1..], &s[1..])
        }
        Some('\\') if pat.len() > 1 => s.first() == Some(&pat[1]) && glob_match(&pat[2..], &s[1..]),
        Some(c) => s.first() == Some(c) && glob_match(&pat[1..], &s[1..]),
    }
}
