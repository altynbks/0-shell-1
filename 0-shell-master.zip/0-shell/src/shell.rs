use crate::commands::{self, reason, take_status, Io, RawStdin};
use crate::jobs::{self, FdGuard};
use crate::parser::{self, AndOr, Cmd, Command, List, ParseError, Pipeline, Redir, RedirOp, Simple};
use crate::{arith, builtins, expand, ls, vars};
use std::fs::{File, OpenOptions};
use std::io::{self, IsTerminal, Read, Write};
use std::os::unix::io::AsRawFd;
use std::path::Path;
use std::sync::Arc;

pub const BUILTINS: &[&str] = &[
    ".", ":", "[", "[[", "bash", "bg", "break", "cat", "cd", "clear", "continue", "cp", "echo", "eval", "exit", "export", "false", "fg",
    "help", "jobs", "kill", "local", "ls", "mkdir", "mv", "printf", "pwd", "read", "return", "rm", "set", "sh", "shift", "sleep",
    "source", "test", "true", "unset", "wait",
];

const IN_PROCESS: &[&str] = &[
    ".", ":", "[", "[[", "bash", "bg", "cd", "eval", "exit", "export", "false", "fg", "jobs", "kill", "local", "printf", "echo", "pwd", "read",
    "return", "set", "sh", "shift", "source", "test", "true", "unset", "wait", "break", "continue",
];

const MAX_FUNCTION_DEPTH: usize = 100;

#[derive(Clone, Copy, PartialEq, Debug)]
pub enum Flow {
    Normal,
    Break(u32),
    Continue(u32),
    Return,
    Exit,

    Interrupt,
}

pub fn run_text(text: &str) -> Flow {
    match parser::parse(text) {
        Ok(list) => exec_list(&list),
        Err(ParseError::Incomplete) => {
            error!("0-shell: syntax error: unexpected end of file");
            vars::set_status(2);
            Flow::Normal
        }
        Err(ParseError::Syntax(msg)) => {
            error!("0-shell: {msg}");
            vars::set_status(2);
            Flow::Normal
        }
    }
}

pub fn run_source(text: &str) -> i32 {
    run_text(text);
    vars::status()
}

pub fn exec_top(list: &List) -> Flow {
    jobs::clear_interrupt();
    match exec_list(list) {
        Flow::Exit => Flow::Exit,
        Flow::Interrupt => {
            vars::set_status(130);
            Flow::Normal
        }
        _ => Flow::Normal,
    }
}

pub fn run_script(path: &str, args: &[String]) -> i32 {
    let text = match builtins::read_script(path) {
        Ok(t) => t,
        Err(e) => {
            error!("0-shell: {e}");
            return 127;
        }
    };
    vars::set_script_name(path);
    vars::set_positional(args.to_vec());
    run_text(&text);
    vars::status()
}

pub fn run_command_string(cmd: &str, name: &str, args: &[String]) -> i32 {
    vars::set_script_name(name);
    vars::set_positional(args.to_vec());
    run_text(cmd);
    vars::status()
}

pub fn exec_list(list: &List) -> Flow {
    for ao in list {
        let flow = exec_andor(ao);
        if flow != Flow::Normal {
            return flow;
        }
        if jobs::interrupted() {
            return Flow::Interrupt;
        }
    }
    Flow::Normal
}

fn exec_andor(ao: &AndOr) -> Flow {
    if ao.background {
        jobs::spawn(&ao.text, true, || {
            exec_andor_fg(ao);
            vars::status()
        });
        vars::set_status(0);
        return Flow::Normal;
    }
    exec_andor_fg(ao)
}

fn exec_andor_fg(ao: &AndOr) -> Flow {
    let flow = exec_pipeline(&ao.first);
    if flow != Flow::Normal {
        return flow;
    }
    for (is_and, pipeline) in &ao.rest {
        let ok = vars::status() == 0;
        if ok == *is_and {
            let flow = exec_pipeline(pipeline);
            if flow != Flow::Normal {
                return flow;
            }
        }
    }
    Flow::Normal
}

fn exec_pipeline(pl: &Pipeline) -> Flow {
    let flow = if pl.cmds.len() == 1 {
        exec_command(&pl.cmds[0], &pl.text)
    } else {
        let stages: Vec<Box<dyn FnOnce() -> i32 + '_>> = pl
            .cmds
            .iter()
            .map(|c| {
                Box::new(move || {
                    exec_command(c, &pl.text);
                    vars::status()
                }) as Box<dyn FnOnce() -> i32 + '_>
            })
            .collect();
        let code = if jobs::interactive() && !jobs::in_child() {
            jobs::spawn(&pl.text, false, || jobs::pipeline(stages))
        } else {
            jobs::pipeline(stages)
        };
        vars::set_status(code);
        Flow::Normal
    };
    if pl.negate && flow == Flow::Normal {
        vars::set_status(if vars::status() == 0 { 1 } else { 0 });
    }
    flow
}

fn exec_command(c: &Command, text: &str) -> Flow {
    match &c.cmd {
        Cmd::Simple(sc) => exec_simple(sc, text),
        Cmd::Func { name, body } => {
            vars::define_function(name, Arc::clone(body));
            vars::set_status(0);
            Flow::Normal
        }
        other => match apply_redirs(&c.redirs) {
            Some(_guards) => exec_compound(other),
            None => {
                vars::set_status(1);
                Flow::Normal
            }
        },
    }
}

fn loop_flow(flow: Flow) -> Option<Flow> {

    match flow {
        Flow::Normal | Flow::Continue(1) => None,
        Flow::Break(1) => Some(Flow::Normal),
        Flow::Break(n) => Some(Flow::Break(n - 1)),
        Flow::Continue(n) => Some(Flow::Continue(n - 1)),
        other => Some(other),
    }
}

fn arith_value(expr: &str, what: &str) -> Option<i64> {
    match arith::eval(&expand::string(expr)) {
        Ok(v) => Some(v),
        Err(msg) => {
            error!("0-shell: {what}: {msg}");
            None
        }
    }
}

fn exec_compound(cmd: &Cmd) -> Flow {
    match cmd {
        Cmd::If { arms, otherwise } => {
            for (cond, body) in arms {
                let flow = exec_list(cond);
                if flow != Flow::Normal {
                    return flow;
                }
                if vars::status() == 0 {
                    return exec_list(body);
                }
            }
            vars::set_status(0);
            match otherwise {
                Some(body) => exec_list(body),
                None => Flow::Normal,
            }
        }
        Cmd::While { cond, body, until } => {
            vars::set_status(0);
            loop {
                let flow = exec_list(cond);
                if flow != Flow::Normal {
                    return flow;
                }
                if (vars::status() == 0) == *until {
                    break;
                }
                if let Some(out) = loop_flow(exec_list(body)) {
                    return out;
                }
            }
            Flow::Normal
        }
        Cmd::For { var, items, body } => {
            let values: Vec<String> = match items {
                Some(words) => words.iter().flat_map(|w| expand::fields(w)).collect(),
                None => vars::positional(),
            };
            vars::set_status(0);
            for value in values {
                vars::set(var, &value);
                if let Some(out) = loop_flow(exec_list(body)) {
                    return out;
                }
            }
            Flow::Normal
        }
        Cmd::ArithFor { init, cond, step, body } => {
            if arith_value(init, "((").is_none() {
                vars::set_status(1);
                return Flow::Normal;
            }
            vars::set_status(0);
            loop {
                if !cond.is_empty() {
                    match arith_value(cond, "((") {
                        Some(0) | None => break,
                        Some(_) => {}
                    }
                }
                if let Some(out) = loop_flow(exec_list(body)) {
                    return out;
                }
                if arith_value(step, "((").is_none() {
                    break;
                }
            }
            Flow::Normal
        }
        Cmd::Case { word, arms } => {
            let subject: Vec<char> = expand::string(word).chars().collect();
            vars::set_status(0);
            for (patterns, body) in arms {
                let hit = patterns.iter().any(|p| expand::glob_match(&expand::string(p).chars().collect::<Vec<_>>(), &subject));
                if hit {
                    return exec_list(body);
                }
            }
            Flow::Normal
        }
        Cmd::Group(body) => exec_list(body),
        Cmd::Subshell(body) => {
            let code = jobs::isolated("( ... )", || {
                exec_list(body);
                vars::status()
            });
            vars::set_status(code);
            Flow::Normal
        }
        Cmd::Arith(expr) => {
            match arith_value(expr, "((") {
                Some(v) => vars::set_status(if v != 0 { 0 } else { 1 }),
                None => vars::set_status(1),
            }
            Flow::Normal
        }
        Cmd::Simple(_) | Cmd::Func { .. } => Flow::Normal,
    }
}

fn exec_simple(sc: &Simple, text: &str) -> Flow {
    expand::take_subst_status();
    let mut args: Vec<String> = if sc.words.first().map(String::as_str) == Some("[[") {

        sc.words.iter().map(|w| expand::string(w)).collect()
    } else {
        sc.words.iter().flat_map(|w| expand::fields(w)).collect()
    };
    let assigns: Vec<(&String, String)> = sc.assigns.iter().map(|(n, v)| (n, expand::string(v))).collect();

    if args.is_empty() {
        for (name, value) in &assigns {
            vars::set(name, value);
        }
        if !sc.redirs.is_empty() {

            let _ = apply_redirs(&sc.redirs);
        }
        vars::set_status(expand::take_subst_status().unwrap_or(0));
        return Flow::Normal;
    }

    let saved: Vec<(&String, Option<String>)> = assigns.iter().map(|(n, _)| (*n, vars::get(n))).collect();
    for (name, value) in &assigns {
        vars::set(name, value);
    }
    let name = args.remove(0);
    let flow = run_command(&name, &args, &sc.redirs, text);
    for (name, old) in saved.into_iter().rev() {
        match old {
            Some(v) => vars::set(name, &v),
            None => vars::unset(name),
        }
    }
    flow
}

fn numeric(arg: Option<&String>, default: i32) -> i32 {
    arg.and_then(|a| a.parse().ok()).unwrap_or(default)
}

fn run_command(name: &str, args: &[String], redirs: &[Redir], text: &str) -> Flow {
    if name != "exit" && !jobs::in_child() {
        jobs::clear_exit_warning();
    }
    match name {
        "exit" => {
            let code = match args.first() {
                Some(a) => match a.parse::<i32>() {
                    Ok(c) => c,
                    Err(_) => {
                        error!("exit: {a}: numeric argument required");
                        2
                    }
                },
                None => vars::status(),
            };
            if !jobs::in_child() && !jobs::confirm_exit() {
                return Flow::Normal;
            }
            vars::set_status(code & 0xff);
            return Flow::Exit;
        }
        "return" => {
            vars::set_status(numeric(args.first(), vars::status()) & 0xff);
            return Flow::Return;
        }
        "break" | "continue" => {
            let n = numeric(args.first(), 1).max(1) as u32;
            vars::set_status(0);
            return if name == "break" { Flow::Break(n) } else { Flow::Continue(n) };
        }
        _ => {}
    }

    if let Some(body) = vars::function(name) {
        return match apply_redirs(redirs) {
            Some(_guards) => call_function(&body, args),
            None => {
                vars::set_status(1);
                Flow::Normal
            }
        };
    }

    match name {
        "source" | "." => return source(args, redirs),
        "eval" => {
            let Some(_guards) = apply_redirs(redirs) else {
                vars::set_status(1);
                return Flow::Normal;
            };
            return run_text(&args.join(" "));
        }
        "sh" | "bash" => {
            let Some(_guards) = apply_redirs(redirs) else {
                vars::set_status(1);
                return Flow::Normal;
            };
            let code = run_sh(name, args);
            vars::set_status(code);
            return Flow::Normal;
        }
        _ => {}
    }

    if name.contains('/') && Path::new(name).is_file() {
        let Some(_guards) = apply_redirs(redirs) else {
            vars::set_status(1);
            return Flow::Normal;
        };
        let code = run_sh("sh", &[&[name.to_string()], args].concat());
        vars::set_status(code);
        return Flow::Normal;
    }

    let mut argv = vec![name.to_string()];
    argv.extend_from_slice(args);
    let inline = IN_PROCESS.contains(&name) || !jobs::interactive() || jobs::in_child();
    let code = if inline { run_inline(&argv, redirs) } else { jobs::spawn(text, false, || run_inline(&argv, redirs)) };
    vars::set_status(code);
    if jobs::interrupted() {
        return Flow::Interrupt;
    }
    Flow::Normal
}

fn call_function(body: &Arc<Command>, args: &[String]) -> Flow {
    if vars::function_depth() >= MAX_FUNCTION_DEPTH {
        error!("0-shell: maximum function nesting level exceeded ({MAX_FUNCTION_DEPTH})");
        vars::set_status(1);
        return Flow::Normal;
    }
    let saved = vars::set_positional(args.to_vec());
    vars::push_frame();
    let flow = exec_command(body, "function");
    vars::pop_frame();
    vars::set_positional(saved);
    match flow {
        Flow::Return | Flow::Break(_) | Flow::Continue(_) => Flow::Normal,
        other => other,
    }
}

fn source(args: &[String], redirs: &[Redir]) -> Flow {
    let Some(path) = args.first() else {
        error!(".: filename argument required");
        vars::set_status(2);
        return Flow::Normal;
    };
    let text = match builtins::read_script(path) {
        Ok(t) => t,
        Err(e) => {
            error!("source: {e}");
            vars::set_status(1);
            return Flow::Normal;
        }
    };
    let Some(_guards) = apply_redirs(redirs) else {
        vars::set_status(1);
        return Flow::Normal;
    };
    let saved = (args.len() > 1).then(|| vars::set_positional(args[1..].to_vec()));
    let flow = run_text(&text);
    if let Some(old) = saved {
        vars::set_positional(old);
    }
    match flow {
        Flow::Return => Flow::Normal,
        other => other,
    }
}

fn run_sh(shell: &str, args: &[String]) -> i32 {
    let (text, name, rest, label): (String, String, Vec<String>, String) = match args.first().map(String::as_str) {
        Some("-c") => match args.get(1) {
            Some(cmd) => (cmd.clone(), args.get(2).cloned().unwrap_or_else(|| shell.to_string()), args.iter().skip(3).cloned().collect(), format!("{shell} -c")),
            None => {
                error!("{shell}: -c: option requires an argument");
                return 2;
            }
        },
        Some(file) => match builtins::read_script(file) {
            Ok(t) => (t, file.to_string(), args[1..].to_vec(), format!("{shell} {file}")),
            Err(e) => {
                error!("{shell}: {e}");
                return 127;
            }
        },
        None => {
            error!("{shell}: usage: {shell} script [args...]  |  {shell} -c commands");
            return 2;
        }
    };
    jobs::isolated(&label, move || {
        vars::set_script_name(&name);
        vars::set_positional(rest);
        run_text(&text);
        vars::status()
    })
}

fn apply_redirs(redirs: &[Redir]) -> Option<Vec<FdGuard>> {
    let mut guards = Vec::new();
    for r in redirs {
        match r.op {
            RedirOp::ErrToOut => guards.push(FdGuard::redirect(1, 2)),
            RedirOp::OutToErr => guards.push(FdGuard::redirect(2, 1)),
            _ => {
                let path = expand::string(&r.target);
                if path.is_empty() {
                    error!("0-shell: {}: ambiguous redirect", r.target);
                    return None;
                }
                let (append, fd) = match r.op {
                    RedirOp::In => (false, 0),
                    RedirOp::Out => (false, 1),
                    RedirOp::Append => (true, 1),
                    RedirOp::ErrOut => (false, 2),
                    _ => (true, 2),
                };
                let opened = if fd == 0 {
                    File::open(&path)
                } else {
                    OpenOptions::new().write(true).create(true).append(append).truncate(!append).open(&path)
                };
                match opened {
                    Ok(f) => guards.push(FdGuard::redirect(f.as_raw_fd(), fd)),
                    Err(e) => {
                        error!("0-shell: {path}: {}", reason(&e));
                        return None;
                    }
                }
            }
        }
    }
    Some(guards)
}

fn run_inline(args: &[String], redirs: &[Redir]) -> i32 {
    let Some(_guards) = apply_redirs(redirs) else { return 1 };
    let color = io::stdout().is_terminal();
    let mut out = io::stdout().lock();
    let code = run(args, &mut RawStdin, &mut out, color);
    let _ = out.flush();
    code
}

fn run(args: &[String], input: &mut dyn Read, out: &mut dyn Write, color: bool) -> i32 {
    let _ = take_status();
    let mut io = Io { input, out, color };
    let rest = &args[1..];
    match args[0].as_str() {
        "echo" => commands::echo(rest, &mut io),
        "cd" => commands::cd(rest, &mut io),
        "pwd" => commands::pwd(&mut io),
        "cat" => commands::cat(rest, &mut io),
        "ls" => ls::ls(rest, &mut io),
        "export" => commands::export(rest, &mut io),
        "help" => commands::help(&mut io),
        "sleep" => commands::sleep(rest),
        "jobs" => jobs::jobs(rest, io.out),
        "fg" => jobs::fg(rest),
        "bg" => jobs::bg(rest, io.out),
        "kill" => jobs::kill_cmd(rest, io.out),
        "wait" => commands::set_status(jobs::wait_all()),
        "clear" => say!(io.out, "\x1b[2J\x1b[H"),
        "cp" => commands::cp(rest),
        "rm" => commands::rm(rest),
        "mv" => commands::mv(rest),
        "mkdir" => commands::mkdir(rest),
        "test" | "[" | "[[" => builtins::test(&args[0], rest),
        "read" => builtins::read(rest, &mut io),
        "printf" => builtins::printf(rest, &mut io),
        "shift" => builtins::shift(rest),
        "unset" => builtins::unset(rest),
        "local" => builtins::local(rest),
        "set" => builtins::set(rest, &mut io),
        "true" | ":" => {}
        "false" => commands::set_status(1),
        other => {
            let msg = format!("Command '{other}' not found");
            if io::stdout().is_terminal() {
                println!("\x1b[31m{msg}\x1b[0m");
            } else {
                println!("{msg}");
            }
            return 127;
        }
    }
    let _ = io.out.flush();
    take_status()
}
