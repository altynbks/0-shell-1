#!/bin/sh
# create-dir: ask for a directory name and create it unless it already exists.

echo "Enter directory name"
read name

if [ -z "$name" ]; then
    echo "No directory name given"
    exit 1
fi

if [ -d "$name" ]; then
    echo "Directory exist"
else
    mkdir "$name" && echo "Directory created"
fi
