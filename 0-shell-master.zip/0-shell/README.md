# 0-shell — scripting (с бонусами и job control)

    cargo build --release
    ./target/release/0-shell                    # интерактивная оболочка (нужен Linux)
    ./target/release/0-shell script.sh a b      # выполнить скрипт ($0=script.sh, $1=a, $2=b)
    ./target/release/0-shell -c 'for ((i=0;i<3;i++)); do echo $i; done'

Это `job-control` + интерпретатор скриптов. Внешние программы не запускаются: `sh`/`bash` —
встроенные команды оболочки, а не настоящие bash/sh.

## Скрипт create-dir

`create-dir.sh` (копия без расширения — `create-dir`): спрашивает "Enter directory name",
читает имя через `read`; если каталог есть — `Directory exist`, иначе создаёт и пишет `Directory created`.

    $ bash create-dir.sh
    Enter directory name
    Example
    Directory created

## Что понимает интерпретатор

- Переменные: `X=1`, `X=1 cmd`, `export`, `unset`, `local`, `$X ${X:-d} ${X:=d} ${X:+a} ${#X} ${X#p} ${X%p} ${X/a/b} ${X:1:2}`
- Параметры: `$0 $1.. $# $@ $* $? $$ $!`, `shift`, `set -- a b`
- Подстановки: `$(cmd)`, `` `cmd` ``, `$((expr))`, `~`, кавычки
- Условия: `if/elif/else/fi`, `&&`, `||`, `!`, `test`, `[ ]`, `[[ ]]`
- Циклы: `for x in ..`, `for ((i=0; i<n; i++))`, `while`, `until`, `break`, `continue`
- `case ... esac`, функции (`name() { }`, `function name { }`, `return`, `local`), `(( ))`, `( )`, `{ }`
- `read`, `printf`, `echo -n -e`, `> >> < 2> 2>> 2>&1 >&2`, пайпы (pipe+fork)
- `source`/`.`, `eval`, `sh`/`bash file|-c`, `./file`, `exit [n]`, `wait`
- Job control: `&`, `jobs`, `fg`, `bg`, `kill`, Ctrl+Z, Ctrl+C

Не поддерживается: here-doc, глоббинг, `$IFS`, массивы, `=~`.

## Файлы

`main.rs` (режимы), `parser.rs` (лексер+AST), `expand.rs`, `arith.rs`, `shell.rs` (исполнитель),
`builtins.rs`, `vars.rs`, `jobs.rs`, `commands.rs`, `ls.rs`, `editor.rs`; `examples/` + `sh examples/check.sh`.
